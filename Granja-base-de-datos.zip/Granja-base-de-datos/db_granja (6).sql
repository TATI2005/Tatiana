-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-04-2025 a las 03:31:53
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_granja`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarStock` (IN `p_id_producto` INT, IN `p_cantidad` INT)   BEGIN
    UPDATE productos
    SET Stock = Stock + p_cantidad
    WHERE Id_producto = p_id_producto;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AplicarCupon` (IN `p_id_cupon` INT, IN `p_id_producto` INT)   BEGIN
    DECLARE v_descuento DECIMAL(10,2);

    -- Obtener el descuento del cupón
    SELECT Descuento
    INTO v_descuento
    FROM cupones
    WHERE Id_cupon = p_id_cupon;

    -- Aplicar el descuento al producto indicado
    UPDATE productos
    SET Precio = GREATEST(Precio - v_descuento, 0)
    WHERE Id_producto = p_id_producto;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `CrearOrden` (IN `p_id_orden` INT, IN `p_id_usuario` INT, IN `p_total` DECIMAL(10,2), IN `p_estado` VARCHAR(50), IN `p_cantidad` INT)   BEGIN
    INSERT INTO ordenes (Id_orden, Id_usuario, Cantidad, Total, Estado, Fecha_orden)
    VALUES (p_id_orden, p_id_usuario, p_cantidad, p_total,p_estado, NOW());
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerCategoriaPorProducto` (IN `p_id_producto` INT)   BEGIN
    SELECT Categoria
    FROM productos
    WHERE Id_producto = p_id_producto;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ReembolsarOrden` (IN `p_id_orden` INT)   BEGIN
    UPDATE ordenes
    SET Estado = 'Reembolsada'
    WHERE Id_orden = p_id_orden;
END$$

--
-- Funciones
--
CREATE DEFINER=`root`@`localhost` FUNCTION `CantidadAnimalesPorEspecie` (`p_especie` VARCHAR(50)) RETURNS INT(11) DETERMINISTIC BEGIN
    DECLARE v_total INT;
    SELECT SUM(Cantidad) INTO v_total
    FROM animales
    WHERE Especie = p_especie;
    RETURN IFNULL(v_total, 0);
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `CantidadDisponible` (`p_id_producto` INT) RETURNS INT(11) DETERMINISTIC BEGIN
    DECLARE v_stock INT;
    SELECT Stock INTO v_stock FROM productos WHERE Id_producto = p_id_producto;
    RETURN v_stock;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `TipoUsuario` (`p_id_usuario` INT) RETURNS VARCHAR(50) CHARSET utf8mb4 COLLATE utf8mb4_general_ci DETERMINISTIC BEGIN
    DECLARE tipo VARCHAR(50);

    SELECT Tipo_usuario
    INTO tipo
    FROM usuario
    WHERE Id_usuario = p_id_usuario;

    RETURN tipo;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alimentos`
--

CREATE TABLE `alimentos` (
  `Id_alimento` int(11) NOT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_granja` int(11) DEFAULT NULL,
  `Id_ventas` int(11) DEFAULT NULL,
  `Tipo_alimento` varchar(100) DEFAULT NULL,
  `Cantidad_alimento` int(11) DEFAULT NULL,
  `Fecha_alimentacion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `animales`
--

CREATE TABLE `animales` (
  `Id_animal` int(11) NOT NULL,
  `Nombre_cientifico` varchar(100) DEFAULT NULL,
  `Nombre_comun` varchar(100) DEFAULT NULL,
  `Especie` varchar(100) DEFAULT NULL,
  `Edad` int(11) DEFAULT NULL,
  `Cantidad` int(11) DEFAULT NULL,
  `Ubicacion` varchar(255) DEFAULT NULL,
  `Descripcion` text DEFAULT NULL,
  `Fecha_registro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Disparadores `animales`
--
DELIMITER $$
CREATE TRIGGER `auditar_animal` AFTER INSERT ON `animales` FOR EACH ROW BEGIN
    INSERT INTO auditoria_animales (Id_usuario, Id_animal, Accion)
    VALUES (NEW.Id_animal, 'Registro de nuevo animal (sin usuario)');
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `auditar_registro_animal` AFTER INSERT ON `animales` FOR EACH ROW BEGIN
  INSERT INTO auditoria_animales (id_animal, nombre_comun, especie, accion)
  VALUES (NEW.Id_animal, NEW.Nombre_comun, NEW.Especie, 'Registro');
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auditoria`
--

CREATE TABLE `auditoria` (
  `id_auditoria` int(11) NOT NULL,
  `usuario` varchar(100) DEFAULT NULL,
  `accion` varchar(50) DEFAULT NULL,
  `tabla_afectada` varchar(50) DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  `direccion_ip` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `auditoria`
--

INSERT INTO `auditoria` (`id_auditoria`, `usuario`, `accion`, `tabla_afectada`, `fecha`, `direccion_ip`) VALUES
(1, 'root@localhost', 'INSERT', 'pedidos', '2025-04-08 16:44:13', 'localhost'),
(2, 'root@localhost', 'UPDATE', 'pedidos', '2025-04-08 16:45:04', 'localhost'),
(3, 'root@localhost', 'UPDATE', 'productos', '2025-04-08 16:47:54', 'localhost');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auditoria_animales`
--

CREATE TABLE `auditoria_animales` (
  `id_auditoria` int(11) NOT NULL,
  `id_animal` int(11) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `accion` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `Id_cliente` int(11) NOT NULL,
  `Nombre_cliente` varchar(100) DEFAULT NULL,
  `Correo_cliente` varchar(100) DEFAULT NULL,
  `Telefono_cliente` varchar(50) DEFAULT NULL,
  `Id_animal` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`Id_cliente`, `Nombre_cliente`, `Correo_cliente`, `Telefono_cliente`, `Id_animal`) VALUES
(1, 'morel', 'morel123@gmail.com', '312456756', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cupones`
--

CREATE TABLE `cupones` (
  `Id_cupon` int(11) NOT NULL,
  `Codigo` varchar(50) NOT NULL,
  `Descuento` decimal(5,2) NOT NULL,
  `Fecha_inicio` date NOT NULL,
  `Fecha_fin` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cupones`
--

INSERT INTO `cupones` (`Id_cupon`, `Codigo`, `Descuento`, `Fecha_inicio`, `Fecha_fin`) VALUES
(1, 'DESCUENTO10', 0.10, '2025-04-01', '2025-04-30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `diagnostico`
--

CREATE TABLE `diagnostico` (
  `Id_diagnostico` int(11) NOT NULL,
  `Id_reporte` int(11) DEFAULT NULL,
  `Diagnostico` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `diagnostico`
--

INSERT INTO `diagnostico` (`Id_diagnostico`, `Id_reporte`, `Diagnostico`) VALUES
(1, 1, 'diagnostico1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_animal`
--

CREATE TABLE `estado_animal` (
  `Id_estado` int(11) NOT NULL,
  `Estado` enum('Sano','Enfermo','Recuperación') DEFAULT NULL,
  `Fecha_registro` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estado_animal`
--

INSERT INTO `estado_animal` (`Id_estado`, `Estado`, `Fecha_registro`) VALUES
(1, 'Sano', '2025-04-15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evento`
--

CREATE TABLE `evento` (
  `Id_evento` int(11) NOT NULL,
  `Id_historial` int(11) DEFAULT NULL,
  `Tipo_evento` varchar(100) DEFAULT NULL,
  `Fecha_registro` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `evento`
--

INSERT INTO `evento` (`Id_evento`, `Id_historial`, `Tipo_evento`, `Fecha_registro`) VALUES
(1, 1, 'lorem ipsum dolor', '2025-04-20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `granja`
--

CREATE TABLE `granja` (
  `Id_granja` int(11) NOT NULL,
  `Id_usuario` int(11) DEFAULT NULL,
  `Telefono_granja` int(11) DEFAULT NULL,
  `Correo` varchar(50) DEFAULT NULL,
  `Direccion` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `granja`
--

INSERT INTO `granja` (`Id_granja`, `Id_usuario`, `Telefono_granja`, `Correo`, `Direccion`) VALUES
(1, 1, 312456231, 'Granja_la_verde@hotmail.com', 'lorem ipsum dolor');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial`
--

CREATE TABLE `historial` (
  `Id_historial` int(11) NOT NULL,
  `Id_planta` int(11) DEFAULT NULL,
  `Descripcion_evento` text DEFAULT NULL,
  `Fecha_evento` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `historial`
--

INSERT INTO `historial` (`Id_historial`, `Id_planta`, `Descripcion_evento`, `Fecha_evento`) VALUES
(1, 1, 'evento1', '2025-04-04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenes`
--

CREATE TABLE `imagenes` (
  `Id_imagen` int(11) NOT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_planta` int(11) DEFAULT NULL,
  `URL_imagen` varchar(255) DEFAULT NULL,
  `Fecha_subida` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `imagenes`
--

INSERT INTO `imagenes` (`Id_imagen`, `Id_animal`, `Id_planta`, `URL_imagen`, `Fecha_subida`) VALUES
(1, 1, 1, 'https:/ejemplovaca.com', '2025-01-04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `intentos_login`
--

CREATE TABLE `intentos_login` (
  `Id_intento` int(11) NOT NULL,
  `Id_usuario` int(11) NOT NULL,
  `Fecha_intento` timestamp NOT NULL DEFAULT current_timestamp(),
  `Exitoso` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `intentos_login`
--

INSERT INTO `intentos_login` (`Id_intento`, `Id_usuario`, `Fecha_intento`, `Exitoso`) VALUES
(2, 9, '2025-04-08 23:13:12', 1),
(3, 9, '2025-04-08 23:14:50', 0),
(4, 9, '2025-04-08 23:14:55', 0),
(5, 9, '2025-04-08 23:15:00', 0),
(6, 9, '2025-04-08 23:18:26', 1),
(7, 9, '2025-04-08 23:47:03', 1),
(8, 9, '2025-04-09 00:03:04', 1),
(9, 9, '2025-04-09 00:07:21', 1),
(10, 9, '2025-04-09 00:10:54', 1),
(11, 9, '2025-04-09 00:14:41', 1),
(12, 9, '2025-04-09 00:17:26', 1),
(13, 9, '2025-04-09 00:20:15', 1),
(14, 9, '2025-04-09 00:24:36', 1),
(15, 9, '2025-04-09 00:38:28', 1),
(16, 9, '2025-04-09 00:48:37', 1),
(17, 9, '2025-04-09 00:50:02', 1),
(18, 9, '2025-04-09 01:05:05', 1),
(19, 9, '2025-04-09 01:11:54', 1),
(20, 9, '2025-04-09 01:14:30', 1),
(21, 9, '2025-04-09 01:17:51', 1),
(22, 9, '2025-04-09 01:19:36', 1),
(23, 9, '2025-04-09 01:20:17', 1),
(24, 9, '2025-04-09 01:27:53', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ordenes`
--

CREATE TABLE `ordenes` (
  `Id_orden` int(11) NOT NULL,
  `Id_usuario` int(11) DEFAULT NULL,
  `Cantidad` int(11) DEFAULT 1,
  `Total` decimal(10,2) DEFAULT NULL,
  `Fecha_orden` timestamp NOT NULL DEFAULT current_timestamp(),
  `Estado` enum('Reembolsada','Sin reembolsar','Pendiente','Listo') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ordenes`
--

INSERT INTO `ordenes` (`Id_orden`, `Id_usuario`, `Cantidad`, `Total`, `Fecha_orden`, `Estado`) VALUES
(1, 1, 1, 1200.00, '2025-04-08 13:07:56', 'Reembolsada'),
(2, 1, 30, 300.00, '2025-04-08 20:28:36', 'Pendiente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id_pedido` int(11) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `fecha_pedido` datetime DEFAULT current_timestamp(),
  `estado` varchar(50) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id_pedido`, `id_usuario`, `fecha_pedido`, `estado`, `total`) VALUES
(1, 1, '2025-04-30 16:44:13', 'Confirmado', 50.00);

--
-- Disparadores `pedidos`
--
DELIMITER $$
CREATE TRIGGER `trg_auditoria_insert_pedido` AFTER INSERT ON `pedidos` FOR EACH ROW BEGIN
    INSERT INTO auditoria (usuario, accion, tabla_afectada, direccion_ip)
    VALUES (CURRENT_USER(), 'INSERT', 'pedidos', SUBSTRING_INDEX(USER(), '@', -1));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_auditoria_update_pedido` AFTER UPDATE ON `pedidos` FOR EACH ROW BEGIN
    INSERT INTO auditoria (usuario, accion, tabla_afectada, direccion_ip)
    VALUES (CURRENT_USER(), 'UPDATE', 'pedidos', SUBSTRING_INDEX(USER(), '@', -1));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `plantas`
--

CREATE TABLE `plantas` (
  `Id_planta` int(11) NOT NULL,
  `Nombre_cientifico` varchar(100) DEFAULT NULL,
  `Nombre_comun` varchar(100) DEFAULT NULL,
  `Ubicacion_planta` varchar(255) DEFAULT NULL,
  `Estado_planta` enum('Sano','Enfermo','Recuperación') DEFAULT 'Sano',
  `Descripcion` text DEFAULT NULL,
  `Fecha_registro_planta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `plantas`
--

INSERT INTO `plantas` (`Id_planta`, `Nombre_cientifico`, `Nombre_comun`, `Ubicacion_planta`, `Estado_planta`, `Descripcion`, `Fecha_registro_planta`) VALUES
(1, 'aloe vera', 'sabila', 'lugardeaqui1', 'Sano', 'lorem ipsum dolor', '2025-04-08 12:58:32');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `Id_producto` int(11) NOT NULL,
  `Nombre_producto` varchar(100) DEFAULT NULL,
  `Descripcion` text DEFAULT NULL,
  `Categoria` varchar(100) NOT NULL,
  `Precio` decimal(10,2) DEFAULT NULL,
  `Stock` int(11) DEFAULT NULL,
  `Fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`Id_producto`, `Nombre_producto`, `Descripcion`, `Categoria`, `Precio`, `Stock`, `Fecha_registro`) VALUES
(1, 'carne de res', 'lorem ipsum dolor', 'carne', 19000.90, 180, '2025-04-08 12:23:35');

--
-- Disparadores `productos`
--
DELIMITER $$
CREATE TRIGGER `trg_auditoria_update_producto` AFTER UPDATE ON `productos` FOR EACH ROW BEGIN
    INSERT INTO auditoria (usuario, accion, tabla_afectada, direccion_ip)
    VALUES (CURRENT_USER(), 'UPDATE', 'productos', SUBSTRING_INDEX(USER(), '@', -1));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reportes`
--

CREATE TABLE `reportes` (
  `Id_reporte` int(11) NOT NULL,
  `Id_usuario` int(11) DEFAULT NULL,
  `Id_planta` int(11) DEFAULT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Tipo` enum('Planta','Animal') DEFAULT NULL,
  `Fecha_reporte` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reportes`
--

INSERT INTO `reportes` (`Id_reporte`, `Id_usuario`, `Id_planta`, `Id_animal`, `Tipo`, `Fecha_reporte`) VALUES
(1, 1, 1, 1, 'Planta', '2025-04-08 12:59:04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tratamientos`
--

CREATE TABLE `tratamientos` (
  `Id_tratamiento` int(11) NOT NULL,
  `Id_reporte` int(11) DEFAULT NULL,
  `Descripcion` text DEFAULT NULL,
  `Fecha_inicio` date DEFAULT NULL,
  `Fecha_fin` date DEFAULT NULL,
  `Resultado` enum('Exitoso','En Proceso','Fallido') DEFAULT 'En Proceso'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tratamientos`
--

INSERT INTO `tratamientos` (`Id_tratamiento`, `Id_reporte`, `Descripcion`, `Fecha_inicio`, `Fecha_fin`, `Resultado`) VALUES
(1, 1, 'lorem ipsum dolor', '2025-04-01', '2025-04-27', 'Exitoso');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubicacion`
--

CREATE TABLE `ubicacion` (
  `Id_ubicacion` int(11) NOT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_planta` int(11) DEFAULT NULL,
  `Latitud` decimal(10,8) DEFAULT NULL,
  `Longitud` decimal(11,8) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ubicacion`
--

INSERT INTO `ubicacion` (`Id_ubicacion`, `Id_animal`, `Id_planta`, `Latitud`, `Longitud`, `Descripcion`) VALUES
(1, 1, 1, 1.67000000, 2.50000000, 'lorem ipsum dolor');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `Id_usuario` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `telefono` int(11) DEFAULT NULL,
  `Tipo_usuario` varchar(100) DEFAULT NULL,
  `contraseña` varchar(100) DEFAULT NULL,
  `bloqueado` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`Id_usuario`, `nombre`, `correo`, `telefono`, `Tipo_usuario`, `contraseña`, `bloqueado`) VALUES
(1, 'Laura santana', 'laurel23@gmail.com', 320123456, 'Administrador', 'laurel123', 0),
(9, 'tati', 'tat123@gmail.com', 312345678, 'Granjero', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vacunaciones`
--

CREATE TABLE `vacunaciones` (
  `Id_vacunacion` int(11) NOT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_estado` int(11) DEFAULT NULL,
  `vacuna` varchar(100) DEFAULT NULL,
  `Fecha_Vacunacion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vacunaciones`
--

INSERT INTO `vacunaciones` (`Id_vacunacion`, `Id_animal`, `Id_estado`, `vacuna`, `Fecha_Vacunacion`) VALUES
(1, 1, 1, 'vacuna1', '2025-04-26');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas_animales`
--

CREATE TABLE `ventas_animales` (
  `Id_ventas` int(11) NOT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_usuario` int(11) DEFAULT NULL,
  `Id_cliente` int(11) DEFAULT NULL,
  `Id_estado` int(11) DEFAULT NULL,
  `Precio` decimal(10,2) DEFAULT NULL,
  `Fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas_animales`
--

INSERT INTO `ventas_animales` (`Id_ventas`, `Id_animal`, `Id_usuario`, `Id_cliente`, `Id_estado`, `Precio`, `Fecha`) VALUES
(1, 1, 1, 1, 1, 120.00, '2025-04-20');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_resumen_auditoria`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_resumen_auditoria` (
`usuario` varchar(100)
,`accion` varchar(50)
,`tabla_afectada` varchar(50)
,`direccion_ip` varchar(45)
,`fecha` datetime
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_resumen_auditoria`
--
DROP TABLE IF EXISTS `vista_resumen_auditoria`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_resumen_auditoria`  AS SELECT `auditoria`.`usuario` AS `usuario`, `auditoria`.`accion` AS `accion`, `auditoria`.`tabla_afectada` AS `tabla_afectada`, `auditoria`.`direccion_ip` AS `direccion_ip`, `auditoria`.`fecha` AS `fecha` FROM `auditoria` ORDER BY `auditoria`.`fecha` DESC ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alimentos`
--
ALTER TABLE `alimentos`
  ADD PRIMARY KEY (`Id_alimento`),
  ADD KEY `Id_animal` (`Id_animal`),
  ADD KEY `Id_granja` (`Id_granja`),
  ADD KEY `Id_ventas` (`Id_ventas`);

--
-- Indices de la tabla `animales`
--
ALTER TABLE `animales`
  ADD PRIMARY KEY (`Id_animal`),
  ADD UNIQUE KEY `Id_animal` (`Id_animal`),
  ADD KEY `idx_animal_id` (`Id_animal`);

--
-- Indices de la tabla `auditoria`
--
ALTER TABLE `auditoria`
  ADD PRIMARY KEY (`id_auditoria`);

--
-- Indices de la tabla `auditoria_animales`
--
ALTER TABLE `auditoria_animales`
  ADD PRIMARY KEY (`id_auditoria`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`Id_cliente`),
  ADD KEY `Id_animal` (`Id_animal`),
  ADD KEY `idx_cliente_id` (`Id_cliente`);

--
-- Indices de la tabla `cupones`
--
ALTER TABLE `cupones`
  ADD PRIMARY KEY (`Id_cupon`);

--
-- Indices de la tabla `diagnostico`
--
ALTER TABLE `diagnostico`
  ADD PRIMARY KEY (`Id_diagnostico`),
  ADD KEY `Id_reporte` (`Id_reporte`);

--
-- Indices de la tabla `estado_animal`
--
ALTER TABLE `estado_animal`
  ADD PRIMARY KEY (`Id_estado`),
  ADD KEY `idx_estado_id` (`Id_estado`);

--
-- Indices de la tabla `evento`
--
ALTER TABLE `evento`
  ADD PRIMARY KEY (`Id_evento`),
  ADD KEY `Id_historial` (`Id_historial`);

--
-- Indices de la tabla `granja`
--
ALTER TABLE `granja`
  ADD PRIMARY KEY (`Id_granja`),
  ADD KEY `Id_usuario` (`Id_usuario`);

--
-- Indices de la tabla `historial`
--
ALTER TABLE `historial`
  ADD PRIMARY KEY (`Id_historial`),
  ADD KEY `Id_planta` (`Id_planta`);

--
-- Indices de la tabla `imagenes`
--
ALTER TABLE `imagenes`
  ADD PRIMARY KEY (`Id_imagen`),
  ADD KEY `Id_animal` (`Id_animal`),
  ADD KEY `Id_planta` (`Id_planta`);

--
-- Indices de la tabla `intentos_login`
--
ALTER TABLE `intentos_login`
  ADD PRIMARY KEY (`Id_intento`),
  ADD KEY `fk_usuario` (`Id_usuario`);

--
-- Indices de la tabla `ordenes`
--
ALTER TABLE `ordenes`
  ADD PRIMARY KEY (`Id_orden`),
  ADD KEY `idx_orden_usuario` (`Id_usuario`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `plantas`
--
ALTER TABLE `plantas`
  ADD PRIMARY KEY (`Id_planta`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`Id_producto`),
  ADD KEY `idx_producto_id` (`Id_producto`);

--
-- Indices de la tabla `reportes`
--
ALTER TABLE `reportes`
  ADD PRIMARY KEY (`Id_reporte`),
  ADD KEY `reportes_ibfk_1` (`Id_usuario`),
  ADD KEY `reportes_ibfk_2` (`Id_animal`),
  ADD KEY `reportes_ibfk_3` (`Id_planta`),
  ADD KEY `idx_reporte_id` (`Id_reporte`);

--
-- Indices de la tabla `tratamientos`
--
ALTER TABLE `tratamientos`
  ADD PRIMARY KEY (`Id_tratamiento`),
  ADD KEY `Id_reporte` (`Id_reporte`);

--
-- Indices de la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  ADD PRIMARY KEY (`Id_ubicacion`),
  ADD KEY `Id_animal` (`Id_animal`),
  ADD KEY `Id_planta` (`Id_planta`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`Id_usuario`),
  ADD KEY `idx_usuario_id` (`Id_usuario`);

--
-- Indices de la tabla `vacunaciones`
--
ALTER TABLE `vacunaciones`
  ADD PRIMARY KEY (`Id_vacunacion`),
  ADD KEY `Id_animal` (`Id_animal`),
  ADD KEY `Id_estado` (`Id_estado`);

--
-- Indices de la tabla `ventas_animales`
--
ALTER TABLE `ventas_animales`
  ADD PRIMARY KEY (`Id_ventas`),
  ADD KEY `Id_animal` (`Id_animal`),
  ADD KEY `Id_usuario` (`Id_usuario`),
  ADD KEY `Id_cliente` (`Id_cliente`),
  ADD KEY `idx_ventas_id` (`Id_ventas`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alimentos`
--
ALTER TABLE `alimentos`
  MODIFY `Id_alimento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `animales`
--
ALTER TABLE `animales`
  MODIFY `Id_animal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `auditoria`
--
ALTER TABLE `auditoria`
  MODIFY `id_auditoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `auditoria_animales`
--
ALTER TABLE `auditoria_animales`
  MODIFY `id_auditoria` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `Id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `diagnostico`
--
ALTER TABLE `diagnostico`
  MODIFY `Id_diagnostico` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `estado_animal`
--
ALTER TABLE `estado_animal`
  MODIFY `Id_estado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `evento`
--
ALTER TABLE `evento`
  MODIFY `Id_evento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `granja`
--
ALTER TABLE `granja`
  MODIFY `Id_granja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `historial`
--
ALTER TABLE `historial`
  MODIFY `Id_historial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `imagenes`
--
ALTER TABLE `imagenes`
  MODIFY `Id_imagen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `intentos_login`
--
ALTER TABLE `intentos_login`
  MODIFY `Id_intento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `plantas`
--
ALTER TABLE `plantas`
  MODIFY `Id_planta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `Id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `reportes`
--
ALTER TABLE `reportes`
  MODIFY `Id_reporte` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tratamientos`
--
ALTER TABLE `tratamientos`
  MODIFY `Id_tratamiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  MODIFY `Id_ubicacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `Id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `vacunaciones`
--
ALTER TABLE `vacunaciones`
  MODIFY `Id_vacunacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `ventas_animales`
--
ALTER TABLE `ventas_animales`
  MODIFY `Id_ventas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `alimentos`
--
ALTER TABLE `alimentos`
  ADD CONSTRAINT `alimentos_ibfk_1` FOREIGN KEY (`Id_animal`) REFERENCES `animales` (`Id_animal`),
  ADD CONSTRAINT `alimentos_ibfk_2` FOREIGN KEY (`Id_granja`) REFERENCES `granja` (`Id_granja`),
  ADD CONSTRAINT `alimentos_ibfk_3` FOREIGN KEY (`Id_ventas`) REFERENCES `ventas_animales` (`Id_ventas`);

--
-- Filtros para la tabla `diagnostico`
--
ALTER TABLE `diagnostico`
  ADD CONSTRAINT `diagnostico_ibfk_1` FOREIGN KEY (`Id_reporte`) REFERENCES `reportes` (`Id_reporte`);

--
-- Filtros para la tabla `evento`
--
ALTER TABLE `evento`
  ADD CONSTRAINT `evento_ibfk_1` FOREIGN KEY (`Id_historial`) REFERENCES `historial` (`Id_historial`);

--
-- Filtros para la tabla `granja`
--
ALTER TABLE `granja`
  ADD CONSTRAINT `granja_ibfk_1` FOREIGN KEY (`Id_usuario`) REFERENCES `usuario` (`Id_usuario`);

--
-- Filtros para la tabla `historial`
--
ALTER TABLE `historial`
  ADD CONSTRAINT `historial_ibfk_2` FOREIGN KEY (`Id_planta`) REFERENCES `plantas` (`Id_planta`);

--
-- Filtros para la tabla `imagenes`
--
ALTER TABLE `imagenes`
  ADD CONSTRAINT `imagenes_ibfk_2` FOREIGN KEY (`Id_planta`) REFERENCES `plantas` (`Id_planta`);

--
-- Filtros para la tabla `intentos_login`
--
ALTER TABLE `intentos_login`
  ADD CONSTRAINT `fk_usuario` FOREIGN KEY (`Id_usuario`) REFERENCES `usuario` (`Id_usuario`) ON DELETE CASCADE;

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`Id_usuario`);

--
-- Filtros para la tabla `reportes`
--
ALTER TABLE `reportes`
  ADD CONSTRAINT `reportes_ibfk_1` FOREIGN KEY (`Id_usuario`) REFERENCES `usuario` (`Id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `reportes_ibfk_3` FOREIGN KEY (`Id_planta`) REFERENCES `plantas` (`Id_planta`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tratamientos`
--
ALTER TABLE `tratamientos`
  ADD CONSTRAINT `tratamientos_ibfk_1` FOREIGN KEY (`Id_reporte`) REFERENCES `reportes` (`Id_reporte`);

--
-- Filtros para la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  ADD CONSTRAINT `ubicacion_ibfk_2` FOREIGN KEY (`Id_planta`) REFERENCES `plantas` (`Id_planta`);

--
-- Filtros para la tabla `vacunaciones`
--
ALTER TABLE `vacunaciones`
  ADD CONSTRAINT `vacunaciones_ibfk_2` FOREIGN KEY (`Id_estado`) REFERENCES `estado_animal` (`Id_estado`);

--
-- Filtros para la tabla `ventas_animales`
--
ALTER TABLE `ventas_animales`
  ADD CONSTRAINT `ventas_animales_ibfk_2` FOREIGN KEY (`Id_usuario`) REFERENCES `usuario` (`Id_usuario`),
  ADD CONSTRAINT `ventas_animales_ibfk_3` FOREIGN KEY (`Id_cliente`) REFERENCES `clientes` (`Id_cliente`);

DELIMITER $$
--
-- Eventos
--
CREATE DEFINER=`root`@`localhost` EVENT `desbloquear_usuarios` ON SCHEDULE EVERY 1 MINUTE STARTS '2025-04-06 20:50:53' ON COMPLETION NOT PRESERVE ENABLE DO UPDATE usuario u
  JOIN (
      SELECT Id_usuario
      FROM intentos_login
      WHERE Exitoso = 0
      GROUP BY Id_usuario
      HAVING COUNT(*) >= 3 AND MAX(Fecha) <= NOW() - INTERVAL 3 MINUTE
  ) AS bloqueados
  ON u.Id_usuario = bloqueados.Id_usuario
  SET u.bloqueado = 0$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
