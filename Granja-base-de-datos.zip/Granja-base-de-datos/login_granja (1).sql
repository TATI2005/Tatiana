-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-04-2025 a las 03:32:09
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `login_granja`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alimentos`
--

CREATE TABLE `alimentos` (
  `Id_alimento` int(11) DEFAULT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_granja` int(11) DEFAULT NULL,
  `Id_ventas` int(11) DEFAULT NULL,
  `Tipo_alimento` varchar(100) DEFAULT NULL,
  `Cantidad_alimento` int(11) DEFAULT NULL,
  `Fecha_alimentacion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `animales`
--

CREATE TABLE `animales` (
  `Id_animal` int(11) DEFAULT NULL,
  `Nombre_cientifico` varchar(100) DEFAULT NULL,
  `Nombre_comun` varchar(100) DEFAULT NULL,
  `Especie` varchar(100) DEFAULT NULL,
  `Edad` int(11) DEFAULT NULL,
  `Cantidad` int(11) DEFAULT NULL,
  `Ubicacion` varchar(255) DEFAULT NULL,
  `Descripcion` text DEFAULT NULL,
  `Usuario_animal` int(11) DEFAULT NULL,
  `Fecha_registro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auditoria_usuarios`
--

CREATE TABLE `auditoria_usuarios` (
  `Id` int(11) NOT NULL,
  `Id_usuario` int(11) DEFAULT NULL,
  `Accion` varchar(50) DEFAULT NULL,
  `Fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `auditoria_usuarios`
--

INSERT INTO `auditoria_usuarios` (`Id`, `Id_usuario`, `Accion`, `Fecha`) VALUES
(1, 1, 'Usuario creado', '2025-03-27 05:51:21'),
(2, 2, 'Usuario creado', '2025-03-27 05:51:21'),
(3, 3, 'Usuario creado', '2025-03-27 05:51:21');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `Id_cliente` int(50) DEFAULT NULL,
  `Nombre_cliente` varchar(100) DEFAULT NULL,
  `Correo_cliente` varchar(100) DEFAULT NULL,
  `Telefono_cliente` int(50) DEFAULT NULL,
  `Id_animal` int(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `diagnostico`
--

CREATE TABLE `diagnostico` (
  `Id_diagnostico` int(11) DEFAULT NULL,
  `Id_reporte` int(11) DEFAULT NULL,
  `Diagnostico` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_animal`
--

CREATE TABLE `estado_animal` (
  `Id_estado` int(11) DEFAULT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Estado` enum('Sano','Enfermo','Recuperación') DEFAULT NULL,
  `Fecha_registro` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evento`
--

CREATE TABLE `evento` (
  `Id_evento` int(11) DEFAULT NULL,
  `Id_historial` int(11) DEFAULT NULL,
  `Tipo_evento` varchar(100) DEFAULT NULL,
  `Fecha_registro` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `granja`
--

CREATE TABLE `granja` (
  `Id_granja` int(11) DEFAULT NULL,
  `Id_usuario` int(11) DEFAULT NULL,
  `Telefono_granja` int(11) DEFAULT NULL,
  `Correo` varchar(50) DEFAULT NULL,
  `Direccion` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial`
--

CREATE TABLE `historial` (
  `Id_historial` int(11) DEFAULT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_planta` int(11) DEFAULT NULL,
  `Descripcion_evento` text DEFAULT NULL,
  `Fecha_evento` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenes`
--

CREATE TABLE `imagenes` (
  `Id_imagen` int(11) DEFAULT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_planta` int(11) DEFAULT NULL,
  `URL_imagen` varchar(255) DEFAULT NULL,
  `Fecha_subida` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `plantas`
--

CREATE TABLE `plantas` (
  `Id_planta` int(11) DEFAULT NULL,
  `Nombre_cientifico` varchar(100) DEFAULT NULL,
  `Nombre_comun` varchar(100) DEFAULT NULL,
  `Ubicacion_planta` varchar(255) DEFAULT NULL,
  `Estado_planta` enum('Sano','Enfermo','Recuperación') DEFAULT 'Sano',
  `Descripcion` text DEFAULT NULL,
  `Fecha_registro_planta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reportes`
--

CREATE TABLE `reportes` (
  `Id_reporte` int(11) DEFAULT NULL,
  `Id_usuario` int(11) DEFAULT NULL,
  `Id_planta` int(11) DEFAULT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Tipo` enum('Planta','Animal') DEFAULT NULL,
  `Fecha_reporte` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tratamientos`
--

CREATE TABLE `tratamientos` (
  `Id_tratamiento` int(11) DEFAULT NULL,
  `Id_reporte` int(11) DEFAULT NULL,
  `Descripcion` text DEFAULT NULL,
  `Fecha_inicio` date DEFAULT NULL,
  `Fecha_fin` date DEFAULT NULL,
  `Resultado` enum('Exitoso','En Proceso','Fallido') DEFAULT 'En Proceso'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubicacion`
--

CREATE TABLE `ubicacion` (
  `Id_ubicacion` int(11) DEFAULT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_planta` int(11) DEFAULT NULL,
  `Latitud` decimal(10,8) DEFAULT NULL,
  `Longitud` decimal(11,8) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `Id_usuario` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `telefono` int(11) DEFAULT NULL,
  `Tipo_usuario` varchar(100) DEFAULT NULL,
  `contraseña` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`Id_usuario`, `nombre`, `correo`, `telefono`, `Tipo_usuario`, `contraseña`) VALUES
(1, 'sara', 'sara123@gmail.com', 311234567, 'botanica', 'sara123');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vacunaciones`
--

CREATE TABLE `vacunaciones` (
  `Id_vacunacion` int(11) DEFAULT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_estado` int(11) DEFAULT NULL,
  `vacuna` varchar(100) DEFAULT NULL,
  `Fecha_Vacunacion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas_animales`
--

CREATE TABLE `ventas_animales` (
  `Id_ventas` int(11) DEFAULT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_usuario` int(11) DEFAULT NULL,
  `Id_cliente` int(11) DEFAULT NULL,
  `Id_estado` int(11) DEFAULT NULL,
  `Precio` decimal(10,2) DEFAULT NULL,
  `Fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_alimentos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_alimentos` (
`Id_alimento` int(11)
,`Nombre_comun` varchar(100)
,`Tipo_alimento` varchar(100)
,`Cantidad_alimento` int(11)
,`Fecha_alimentacion` date
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_estado_animales`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_estado_animales` (
`Id_animal` int(11)
,`Nombre_comun` varchar(100)
,`Estado` enum('Sano','Enfermo','Recuperación')
,`Fecha_registro` timestamp
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_eventos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_eventos` (
`Id_evento` int(11)
,`Tipo_evento` varchar(100)
,`Fecha_registro` timestamp
,`Descripcion_evento` text
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_plantas_tratamientos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_plantas_tratamientos` (
`Id_planta` int(11)
,`Nombre_comun` varchar(100)
,`Ubicacion_planta` varchar(255)
,`Descripcion` text
,`Resultado` enum('Exitoso','En Proceso','Fallido')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_reportes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_reportes` (
`Id_reporte` int(11)
,`Tipo_usuario` varchar(100)
,`Fecha_reporte` timestamp
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_ubicaciones`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_ubicaciones` (
`Id_ubicacion` int(11)
,`Nombre` varchar(100)
,`Latitud` decimal(10,8)
,`Longitud` decimal(11,8)
,`Descripcion` varchar(255)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_vacunaciones`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_vacunaciones` (
`Id_vacunacion` int(11)
,`Nombre_comun` varchar(100)
,`Vacuna` varchar(100)
,`Fecha_Vacunacion` date
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_ventas_animales`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_ventas_animales` (
`Id_ventas` int(11)
,`Nombre_comun` varchar(100)
,`Precio` decimal(10,2)
,`Fecha` date
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_ventas_detalladas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_ventas_detalladas` (
`Id_ventas` int(11)
,`Nombre_comun` varchar(100)
,`Especie` varchar(100)
,`Nombre_Cliente` varchar(100)
,`Precio` decimal(10,2)
,`Fecha` date
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_alimentos`
--
DROP TABLE IF EXISTS `vista_alimentos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_alimentos`  AS SELECT `alimentos`.`Id_alimento` AS `Id_alimento`, `animales`.`Nombre_comun` AS `Nombre_comun`, `alimentos`.`Tipo_alimento` AS `Tipo_alimento`, `alimentos`.`Cantidad_alimento` AS `Cantidad_alimento`, `alimentos`.`Fecha_alimentacion` AS `Fecha_alimentacion` FROM (`alimentos` join `animales` on(`alimentos`.`Id_animal` = `animales`.`Id_animal`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_estado_animales`
--
DROP TABLE IF EXISTS `vista_estado_animales`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_estado_animales`  AS SELECT `animales`.`Id_animal` AS `Id_animal`, `animales`.`Nombre_comun` AS `Nombre_comun`, `estado_animal`.`Estado` AS `Estado`, `animales`.`Fecha_registro` AS `Fecha_registro` FROM (`estado_animal` join `animales` on(`estado_animal`.`Id_animal` = `animales`.`Id_animal`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_eventos`
--
DROP TABLE IF EXISTS `vista_eventos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_eventos`  AS SELECT `evento`.`Id_evento` AS `Id_evento`, `evento`.`Tipo_evento` AS `Tipo_evento`, `animales`.`Fecha_registro` AS `Fecha_registro`, `historial`.`Descripcion_evento` AS `Descripcion_evento` FROM ((`evento` join `animales` on(`evento`.`Id_evento` = `animales`.`Id_animal`)) join `historial` on(`evento`.`Id_evento` = `historial`.`Id_historial`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_plantas_tratamientos`
--
DROP TABLE IF EXISTS `vista_plantas_tratamientos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_plantas_tratamientos`  AS SELECT `plantas`.`Id_planta` AS `Id_planta`, `plantas`.`Nombre_comun` AS `Nombre_comun`, `plantas`.`Ubicacion_planta` AS `Ubicacion_planta`, `plantas`.`Descripcion` AS `Descripcion`, `tratamientos`.`Resultado` AS `Resultado` FROM (`plantas` join `tratamientos` on(`plantas`.`Id_planta` = `tratamientos`.`Id_tratamiento`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_reportes`
--
DROP TABLE IF EXISTS `vista_reportes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_reportes`  AS SELECT `reportes`.`Id_reporte` AS `Id_reporte`, `usuario`.`Tipo_usuario` AS `Tipo_usuario`, `reportes`.`Fecha_reporte` AS `Fecha_reporte` FROM (`reportes` join `usuario` on(`reportes`.`Id_reporte` = `usuario`.`Id_usuario`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_ubicaciones`
--
DROP TABLE IF EXISTS `vista_ubicaciones`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_ubicaciones`  AS SELECT `ubicacion`.`Id_ubicacion` AS `Id_ubicacion`, `usuario`.`nombre` AS `Nombre`, `ubicacion`.`Latitud` AS `Latitud`, `ubicacion`.`Longitud` AS `Longitud`, `ubicacion`.`Descripcion` AS `Descripcion` FROM (`ubicacion` join `usuario` on(`ubicacion`.`Id_ubicacion` = `usuario`.`Id_usuario`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_vacunaciones`
--
DROP TABLE IF EXISTS `vista_vacunaciones`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_vacunaciones`  AS SELECT `vacunaciones`.`Id_vacunacion` AS `Id_vacunacion`, `animales`.`Nombre_comun` AS `Nombre_comun`, `vacunaciones`.`vacuna` AS `Vacuna`, `vacunaciones`.`Fecha_Vacunacion` AS `Fecha_Vacunacion` FROM (`vacunaciones` join `animales` on(`vacunaciones`.`Id_animal` = `animales`.`Id_animal`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_ventas_animales`
--
DROP TABLE IF EXISTS `vista_ventas_animales`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_ventas_animales`  AS SELECT `ventas_animales`.`Id_ventas` AS `Id_ventas`, `animales`.`Nombre_comun` AS `Nombre_comun`, `ventas_animales`.`Precio` AS `Precio`, `ventas_animales`.`Fecha` AS `Fecha` FROM (`ventas_animales` join `animales` on(`ventas_animales`.`Id_ventas` = `animales`.`Id_animal`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_ventas_detalladas`
--
DROP TABLE IF EXISTS `vista_ventas_detalladas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_ventas_detalladas`  AS SELECT `ventas_animales`.`Id_ventas` AS `Id_ventas`, `animales`.`Nombre_comun` AS `Nombre_comun`, `animales`.`Especie` AS `Especie`, `clientes`.`Nombre_cliente` AS `Nombre_Cliente`, `ventas_animales`.`Precio` AS `Precio`, `ventas_animales`.`Fecha` AS `Fecha` FROM ((`ventas_animales` join `animales` on(`ventas_animales`.`Id_ventas` = `animales`.`Id_animal`)) join `clientes` on(`ventas_animales`.`Id_ventas` = `clientes`.`Id_cliente`)) ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `auditoria_usuarios`
--
ALTER TABLE `auditoria_usuarios`
  ADD PRIMARY KEY (`Id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`Id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `auditoria_usuarios`
--
ALTER TABLE `auditoria_usuarios`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
