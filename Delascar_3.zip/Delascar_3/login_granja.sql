-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 04-03-2025 a las 13:37:41
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `login_granja`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `animales`
--

CREATE TABLE `animales` (
  `Id` int(11) NOT NULL,
  `Tipo_animal` enum('Pollo','Vaca','Toro','Pez','Cerdo') NOT NULL,
  `Talla` decimal(4,2) DEFAULT NULL,
  `Peso` int(11) DEFAULT NULL,
  `Edad` int(11) DEFAULT NULL,
  `Cantidad` int(11) DEFAULT NULL,
  `Tipo_comida` varchar(150) DEFAULT NULL,
  `Fecha_comida` date DEFAULT NULL,
  `Dueño_animal` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `animales`
--

INSERT INTO `animales` (`Id`, `Tipo_animal`, `Talla`, `Peso`, `Edad`, `Cantidad`, `Tipo_comida`, `Fecha_comida`, `Dueño_animal`) VALUES
(18, 'Pollo', 0.34, 3, 1, 10, 'Granos', '2025-02-23', 10),
(20, 'Vaca', 1.13, 14, 2, 22, 'Heno', '2025-04-02', 11),
(21, 'Pollo', 0.28, 2, 1, 12, 'Maíz', '2025-03-05', 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `Id` int(11) NOT NULL,
  `Usuario` varchar(50) DEFAULT NULL,
  `Correo` varchar(100) DEFAULT NULL,
  `Contraseña` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`Id`, `Usuario`, `Correo`, `Contraseña`) VALUES
(10, 'Mark', 'mark12@gmail.com', 12345),
(11, 'Sofia23', 'sofia45@hotmail.com', 123456),
(12, 'sara salinas', 'sara345@hotmail.com', 12345);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_animales_con_dueño`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_animales_con_dueño` (
`Id_Animal` int(11)
,`Tipo_animal` enum('Pollo','Vaca','Toro','Pez','Cerdo')
,`Talla` decimal(4,2)
,`Peso` int(11)
,`Edad` int(11)
,`Cantidad` int(11)
,`Tipo_comida` varchar(150)
,`Fecha_comida` date
,`Dueño` varchar(50)
,`Correo_Dueño` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_cantidad_comida`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_cantidad_comida` (
`Tipo_animal` enum('Pollo','Vaca','Toro','Pez','Cerdo')
,`Total_Cantidad` decimal(32,0)
,`Tipo_comida` varchar(150)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_peso_promedio`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_peso_promedio` (
`Tipo_animal` enum('Pollo','Vaca','Toro','Pez','Cerdo')
,`Peso_Promedio` decimal(14,4)
,`Tipo_comida` varchar(150)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_ultima_comida`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_ultima_comida` (
`Tipo_animal` enum('Pollo','Vaca','Toro','Pez','Cerdo')
,`Tipo_comida` varchar(150)
,`Ultima_Fecha` date
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_usuario`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_usuario` (
`Id` int(11)
,`Dueño_animal` int(11)
,`Tipo_animal` enum('Pollo','Vaca','Toro','Pez','Cerdo')
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_animales_con_dueño`
--
DROP TABLE IF EXISTS `vista_animales_con_dueño`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_animales_con_dueño`  AS SELECT `a`.`Id` AS `Id_Animal`, `a`.`Tipo_animal` AS `Tipo_animal`, `a`.`Talla` AS `Talla`, `a`.`Peso` AS `Peso`, `a`.`Edad` AS `Edad`, `a`.`Cantidad` AS `Cantidad`, `a`.`Tipo_comida` AS `Tipo_comida`, `a`.`Fecha_comida` AS `Fecha_comida`, `u`.`Usuario` AS `Dueño`, `u`.`Correo` AS `Correo_Dueño` FROM (`animales` `a` join `usuario` `u` on(`a`.`Dueño_animal` = `u`.`Id`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_cantidad_comida`
--
DROP TABLE IF EXISTS `vista_cantidad_comida`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_cantidad_comida`  AS SELECT `a`.`Tipo_animal` AS `Tipo_animal`, sum(`a`.`Cantidad`) AS `Total_Cantidad`, `a`.`Tipo_comida` AS `Tipo_comida` FROM (`animales` `a` join (select distinct `animales`.`Tipo_comida` AS `Tipo_comida` from `animales`) `c` on(`a`.`Tipo_comida` = `c`.`Tipo_comida`)) GROUP BY `a`.`Tipo_animal`, `a`.`Tipo_comida` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_peso_promedio`
--
DROP TABLE IF EXISTS `vista_peso_promedio`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_peso_promedio`  AS SELECT `a`.`Tipo_animal` AS `Tipo_animal`, avg(`a`.`Peso`) AS `Peso_Promedio`, `c`.`Tipo_comida` AS `Tipo_comida` FROM (`animales` `a` join (select distinct `animales`.`Tipo_animal` AS `Tipo_animal`,`animales`.`Tipo_comida` AS `Tipo_comida` from `animales`) `c` on(`a`.`Tipo_animal` = `c`.`Tipo_animal`)) GROUP BY `a`.`Tipo_animal`, `c`.`Tipo_comida` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_ultima_comida`
--
DROP TABLE IF EXISTS `vista_ultima_comida`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_ultima_comida`  AS SELECT `a`.`Tipo_animal` AS `Tipo_animal`, `a`.`Tipo_comida` AS `Tipo_comida`, max(`a`.`Fecha_comida`) AS `Ultima_Fecha` FROM (`animales` `a` join (select distinct `animales`.`Tipo_animal` AS `Tipo_animal` from `animales`) `b` on(`a`.`Tipo_animal` = `b`.`Tipo_animal`)) GROUP BY `a`.`Tipo_animal`, `a`.`Tipo_comida` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_usuario`
--
DROP TABLE IF EXISTS `vista_usuario`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_usuario`  AS SELECT `a`.`Id` AS `Id`, `a`.`Dueño_animal` AS `Dueño_animal`, `a`.`Tipo_animal` AS `Tipo_animal` FROM (`animales` `a` join `usuario` `u` on(`a`.`Dueño_animal` = `u`.`Id`)) ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `animales`
--
ALTER TABLE `animales`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `fk_dueño` (`Dueño_animal`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `animales`
--
ALTER TABLE `animales`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `animales`
--
ALTER TABLE `animales`
  ADD CONSTRAINT `fk_dueño` FOREIGN KEY (`Dueño_animal`) REFERENCES `usuario` (`Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
