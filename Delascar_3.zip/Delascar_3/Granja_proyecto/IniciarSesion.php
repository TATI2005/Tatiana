<?php
    
    session_start();
    include('conexion.php');

    if(isset($_POST['Usuario']) && isset($_POST['Contraseña'])){

        function validate($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        
        $Usuario = validate($_POST['Usuario']);
        $Contraseña = validate($_POST['Contraseña']);
        
        if(empty($Usuario)){
            header("Location: Saludos.php?error=El Usuario o correo es requerido");
            exit();
        }
        elseif(empty($Contraseña)){
            header("Location: Saludos.php?error=La Contraseña es requerida");
            exit();
        }
        else{
            $Sql = "SELECT * FROM usuario WHERE (Usuario = '$Usuario' OR Correo = '$Usuario') AND Contraseña  = '$Contraseña' ";
            $result = mysqli_query($conexion, $Sql);

            if(mysqli_num_rows($result)=== 1){
                $row = mysqli_fetch_assoc($result);

                if(($row['Usuario'] === $Usuario || $row['Correo'] === $Usuario) && $row['Contraseña'] === $Contraseña){
                    $_SESSION['Usuario'] = $row['Usuario'];
                    $_SESSION['Correo'] = $row['Correo'];
                    $_SESSION['Contraseña'] = $row['Contraseña'];
                    $_SESSION['Id'] = $row['Id'];
                    header("Location: Inicio.php");
                    exit();
                }
                else {
                        header("Location: Saludos.php?error=El usuario e correo, o contraseña son incorrectas!");
                        exit();
                }
            }
            else {
                header("Location: Saludos.php?error=El usuario e correo, o contraseña son incorrectas!");
                exit();
            }
        }

    }
    else {
        header("Location: Saludos.php");
        exit();
    }
?>