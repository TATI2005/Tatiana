<?php
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "login_granja"; 

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tipo_animal = $_POST["Tipo_animal"];
    $talla = $_POST["Talla"];
    $peso = $_POST["Peso"];
    $edad = $_POST["Edad"];
    $cantidad = $_POST["Cantidad"];
    $tipo_comida = $_POST["Tipo_comida"];
    $fecha_comida = $_POST["Fecha_comida"];
    $Dueño_animal = isset($_POST["Dueño_animal"]) ? $_POST["Dueño_animal"] : '';

    $sql = "INSERT INTO animales (Tipo_animal, Talla, Peso, Edad, Cantidad, Tipo_comida, Fecha_comida, Dueño_animal) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdiissss", $tipo_animal, $talla, $peso, $edad, $cantidad, $tipo_comida, $fecha_comida, $Dueño_animal);

    if ($stmt->execute()) {
        echo "<script>alert('Registro guardado con éxito'); window.location.href='Saludos.php';</script>";
    } else {
        echo "<script>alert('Error al guardar: " . $stmt->error . "'); window.history.back();</script>";
    }

    $stmt->close();
}


$conn->close();
?>
