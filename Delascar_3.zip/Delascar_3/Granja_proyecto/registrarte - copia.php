<?php
session_start();
include('conexion.php'); 

if (isset($_POST['Usuario'], $_POST['Correo'], $_POST['Contraseña'], $_POST['Rcontraseña'])) {
    
    function validar($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $Usuario = validar($_POST['Usuario']);
    $Correo = validar($_POST['Correo']);
    $Contraseña = validar($_POST['Contraseña']);
    $Rcontraseña = validar($_POST['Rcontraseña']);

    $datosUsuario = "Usuario=$Usuario&Correo=$Correo";

    // Verificar que ningún campo esté vacío
    if (empty($Usuario)) {
        header("Location: Crear.php?error=El usuario es requerido&$datosUsuario");
        exit();
    } elseif (empty($Correo)) {
        header("Location: Crear.php?error=El correo es requerido&$datosUsuario");
        exit();
    } elseif (empty($Contraseña)) {
        header("Location: Crear.php?error=La contraseña es requerida&$datosUsuario");
        exit();
    } elseif (empty($Rcontraseña)) {
        header("Location: Crear.php?error=Repetir la contraseña es requerida&$datosUsuario");
        exit();
    } elseif ($Contraseña !== $Rcontraseña) {
        header("Location: Crear.php?error=Las contraseñas no coinciden&$datosUsuario");
        exit();
    } else {
        if (!$conexion) {
            die("Error de conexión: " . mysqli_connect_error());
        }

        $Usuario = mysqli_real_escape_string($conexion, $Usuario);
        $Correo = mysqli_real_escape_string($conexion, $Correo);

        $sql = "SELECT * FROM usuario WHERE Correo = '$Correo'";
        $query = $conexion->query($sql);

        if ($query->num_rows > 0) {
            header("Location: Crear.php?error=El correo ya está registrado&$datosUsuario");
            exit();
        } else {

            $ContraseñaHash = password_hash($Contraseña, PASSWORD_BCRYPT);

            $sql2 = "INSERT INTO usuario (Usuario, Correo, Contraseña) VALUES ('$Usuario', '$Correo', '$Contraseña')";
            $query2 = $conexion->query($sql2);

            if ($query2) {
                header("Location: Crear.php?success=Usuario creado con éxito");
                exit();
            } else {
                header("Location: Crear.php?error=Error al registrar usuario: " . mysqli_error($conexion));
                exit();
            }
        }
    }
} else {
    header("Location: Crear.php");
    exit();
}
?>
