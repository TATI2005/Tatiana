<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="CSS/registro.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<form action="registrarte.php" method="POST"> <!-- Corrección del método -->
    <img src="IMG/Vanilla-PMP_Collection-Carousel-0_Buzzy-Bees_1280x768.jpg">
    <h1>REGÍSTRATE GRANJER@!</h1>

    <?php if(isset($_GET['error'])){ ?>
        <p class="error"><?php echo htmlspecialchars($_GET['error']); ?></p>
    <?php } ?>
    <?php if(isset($_GET['success'])){ ?>
        <p class="success"><?php echo htmlspecialchars($_GET['success']); ?></p>
    <?php } ?>
    <hr>

    <label for="Usuario">
        <i class="fa-solid fa-user"></i> Usuario:
    </label>
    <input type="text" name="Usuario" placeholder="Crea un nombre de usuario" required>

    <label for="Correo">
        <i class="fa-solid fa-envelope"></i> Correo:
    </label>
    <input type="email" name="Correo" placeholder="Ingrese su correo electrónico" required>

    <label for="Contraseña">
        <i class="fa-solid fa-unlock"></i> Contraseña:
    </label>
    <input type="password" name="Contraseña" placeholder="Ingrese una contraseña" required>

    <label for="Rcontraseña">
        <i class="fa-solid fa-unlock"></i> Confirmar Contraseña:
    </label>
    <input type="password" name="Rcontraseña" placeholder="Repita la contraseña" required>

    <hr><br>

    <button type="submit">Registrarse</button>
    <a class="enlace" href="Saludos.php">Ingresar</a>

    <div class="regreso-container">
        <a class="Regreso" href="Saludos.php"><i class="fa-solid fa-arrow-left"></i></a>
    </div>
</form>
</body>
</html>