<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer">
    <link rel="stylesheet" href="CSS/index.css">
    <title>Inicio de Sesión</title>
</head>
<body>
    <form action="IniciarSesion.php" method="POST">
        <img src="IMG/Vanilla-PMP_Collection-Carousel-0_Buzzy-Bees_1280x768.jpg">
        <h1>INICIA SESIÓN GRANJER@</h1>
        <hr>
        
        <?php
        if (isset($_GET['error'])) {
            echo '<p class="error">' . htmlspecialchars($_GET['error']) . '</p>';
        }
        ?>

        <label for="usuario"><i class="fa-solid fa-user"></i> Usuario</label>
        <input type="text" name="Usuario" id="usuario" placeholder="Ingrese su usuario o correo" required>

        <label for="contraseña"><i class="fa-solid fa-unlock"></i> Contraseña</label>
        <input type="password" name="Contraseña" id="contraseña" placeholder="Ingrese su contraseña" required>

        <hr>
        <button type="submit">Iniciar Sesión</button>
        <a href="Crear.php">Registrarse</a>
    </form>
</body>
</html>
