<?php
$host = "localhost";
$User = "root";
$Pass = "";
$db = "login_granja";

$conexion = mysqli_connect($host, $User, $Pass, $db);

if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}
?>