-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 04-03-2025 a las 13:38:37
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `restaurante_latatis`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `Actualizacion_Cliente` (IN `id_cliente` INT(11), IN `nombre_cliente` VARCHAR(50), IN `telefono` INT(11), IN `direccion` VARCHAR(100))   BEGIN
     INSERT INTO  clientes(nombre_cliente,telefono, direccion) VALUES 
     (clientes, telefono, direccion);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarClientePorNombre` (IN `p_nombre_cliente` VARCHAR(50))   BEGIN
    SELECT * FROM clientes WHERE nombre_cliente LIKE CONCAT('%', p_nombre_cliente, '%');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ClienteExiste` (IN `p_id_cliente` INT)   BEGIN
    SELECT CASE 
        WHEN EXISTS (SELECT 1 FROM clientes WHERE id_cliente = p_id_cliente) 
        THEN 'Sí' 
        ELSE 'No' 
    END AS existe;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ContarClientes` ()   BEGIN
    SELECT COUNT(*) AS total_clientes FROM clientes;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarCliente` (IN `p_nombre_cliente` VARCHAR(50), IN `p_telefono` INT(11), IN `p_direccion` VARCHAR(100))   BEGIN
    INSERT INTO clientes (nombre_cliente, telefono, direccion) 
    VALUES (p_nombre_cliente, p_telefono, p_direccion);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Nivelacion_salario` ()   BEGIN
    SELECT clientes.id_cliente, platillos.nombre_platillo, platillos.precio_platillo
    FROM clientes JOIN platillos ON clientes.id_cliente = platillos.id_platillo;

 END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerClientePorID` (IN `p_id_cliente` INT)   BEGIN
    SELECT * FROM clientes WHERE id_cliente = p_id_cliente;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerClientes` ()   BEGIN
    SELECT * FROM clientes;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `nombre_cliente` varchar(50) DEFAULT NULL,
  `telefono` int(11) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nombre_cliente`, `telefono`, `direccion`) VALUES
(1, 'Carlos Samuel', 312456789, 'silencio'),
(2, 'Juan de dios', 311234567, 'pan de yuca'),
(3, 'Cangreliano', 312445678, 'silencio'),
(4, 'Manuel espíritu', 317456329, 'reposo'),
(5, 'Mariela', 318456329, 'margarita'),
(6, 'Encarnacion', 319456329, 'kennedy'),
(7, 'Davila', 314545569, 'tomas perez'),
(8, 'Miguel', 318993549, 'samper'),
(9, 'Delascar', 312456789, 'la playita'),
(10, 'Kristian ', 348349589, 'medrano'),
(11, 'Amancio', 312444556, 'santo domingo'),
(12, 'Brayan', 311233451, 'la esmeralda'),
(13, 'Ramón', 301500376, 'yesca grande'),
(14, 'Cornelia', 308445666, 'santo domingo'),
(15, 'Emigrenol', 312233452, 'medrano'),
(16, 'Jhonatan', 312334456, 'yesquita'),
(17, 'Ruperto Mena', 312234551, 'centro'),
(18, 'Yiskar', 317232435, 'caraño'),
(19, 'Alirio', 322343431, 'santo domingo'),
(20, 'melda ', 312456782, 'las americas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `id_empleado` int(11) NOT NULL,
  `nombre_empleado` varchar(50) DEFAULT NULL,
  `telefono_empleado` varchar(50) DEFAULT NULL,
  `documento` varchar(50) DEFAULT NULL,
  `correo_electronico` varchar(50) DEFAULT NULL,
  `direccion_empleado` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`id_empleado`, `nombre_empleado`, `telefono_empleado`, `documento`, `correo_electronico`, `direccion_empleado`) VALUES
(1, 'Juan Pérez', '3145678901', '1001234567', 'juan.perez@email.com', 'La Yesquita'),
(2, 'María Gómez', '3156789012', '1002345678', 'maria.gomez@email.com', 'silencio'),
(3, 'Carlos Rodríguez', '3167890123', '1003456789', 'carlos.rodriguez@email.com', 'El Porvenir'),
(4, 'Ana Torres', '3178901234', '1004567890', 'ana.torres@email.com', 'San Vicente'),
(5, 'Pedro Martínez', '3189012345', '1005678901', 'pedro.martinez@email.com', 'La Aurora'),
(6, 'Laura Sánchez', '3190123456', '1006789012', 'laura.sanchez@email.com', 'Medrano'),
(7, 'Diego Castro', '3201234567', '1007890123', 'diego.castro@email.com', 'Buenos Aires'),
(8, 'Sofía Herrera', '3212345678', '1008901234', 'sofia.herrera@email.com', 'Samper'),
(9, 'Ricardo Ríos', '3223456789', '1009012345', 'ricardo.rios@email.com', 'El Futuro'),
(10, 'Valentina López', '3234567890', '1010123456', 'valentina.lopez@email.com', 'San José'),
(11, 'Javier Molina', '3245678901', '1011234567', 'javier.molina@email.com', 'silencio'),
(12, 'Andrea Ramírez', '3256789012', '1012345678', 'andrea.ramirez@email.com', 'Cruz Roja'),
(13, 'Luis Fernández', '3112233445', '1001234567', 'luis.fernandez@email.com', 'samper'),
(14, 'Ana Martínez', '3209988776', '1007654321', 'ana.martinez@email.com', 'santo domingo'),
(15, 'Carlos Rodríguez', '3156677889', '1005678901', 'carlos.rodriguez@email.com', 'silencio'),
(16, 'María López', '3185566778', '1003456789', 'maria.lopez@email.com', 'buenos aires'),
(17, 'Pedro González', '3223344556', '1002345678', 'pedro.gonzalez@email.com', 'reposo'),
(18, 'Laura Torres', '3101122334', '1006789012', 'laura.torres@email.com', 'medrano'),
(19, 'Jorge Ramírez', '3198899001', '1007890123', 'jorge.ramirez@email.com', 'Caraño'),
(20, 'Gabriela Herrera', '3127766554', '1008901234', 'gabriela.herrera@email.com', 'Las Americas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE `estado` (
  `id_estado` int(11) NOT NULL,
  `id_reserva` int(11) DEFAULT NULL,
  `id_mesa` int(11) DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL,
  `confirmacion_estado` varchar(100) DEFAULT NULL,
  `fecha_confirmacion_estado` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `estado`
--

INSERT INTO `estado` (`id_estado`, `id_reserva`, `id_mesa`, `estado`, `confirmacion_estado`, `fecha_confirmacion_estado`) VALUES
(1, 1, 5, 'Pendiente', 'No', '2025-02-10'),
(2, 2, 8, 'Confirmado', 'Sí', '2025-02-20'),
(3, 3, 3, 'Cancelado', 'No', '2025-03-03'),
(4, 4, 6, 'Pendiente', 'No', '2025-03-02'),
(5, 5, 2, 'Confirmado', 'Sí', '2025-02-22'),
(6, 6, 9, 'Pendiente', 'No', '2025-02-09'),
(7, 7, 4, 'Confirmado', 'Sí', '2025-02-23'),
(8, 8, 7, 'Cancelado', 'No', '2025-03-09'),
(9, 9, 1, 'Pendiente', 'No', '2025-02-18'),
(10, 10, 10, 'Confirmado', 'Sí', '2025-02-25'),
(11, 11, 12, 'Pendiente', 'No', '2025-03-11'),
(12, 12, 14, 'Confirmado', 'Sí', '2025-02-26'),
(13, 13, 11, 'Cancelado', 'No', '2025-03-21'),
(14, 14, 13, 'Pendiente', 'No', '2025-03-19'),
(15, 15, 15, 'Confirmado', 'Sí', '2025-03-30'),
(16, 16, 17, 'Pendiente', 'No', '2025-03-12'),
(17, 17, 16, 'Cancelado', 'No', '2025-03-09'),
(18, 18, 18, 'Confirmado', 'Sí', '2025-03-18'),
(19, 19, 19, 'Pendiente', 'No', '2025-03-05'),
(20, 20, 20, 'Confirmado', 'Sí', '2025-03-12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mesa`
--

CREATE TABLE `mesa` (
  `id_mesa` int(11) NOT NULL,
  `id_reserva` int(11) DEFAULT NULL,
  `cantidad_persona_mesa` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `mesa`
--

INSERT INTO `mesa` (`id_mesa`, `id_reserva`, `cantidad_persona_mesa`) VALUES
(1, 1, 4),
(2, 2, 2),
(3, 3, 6),
(4, 4, 4),
(5, 5, 8),
(6, 6, 2),
(7, 7, 6),
(8, 8, 4),
(9, 9, 2),
(10, 10, 6),
(11, 11, 8),
(12, 12, 4),
(13, 13, 2),
(14, 14, 6),
(15, 15, 4),
(16, 16, 8),
(17, 17, 2),
(18, 18, 6),
(19, 19, 4),
(20, 20, 8);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id_pedido` int(11) NOT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `id_platillo` int(11) DEFAULT NULL,
  `confirmacion_pedido` varchar(100) DEFAULT NULL,
  `total_pedido` int(11) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id_pedido`, `id_empleado`, `id_platillo`, `confirmacion_pedido`, `total_pedido`, `id_cliente`) VALUES
(1, 1, 5, 'Sí', 20000, 1),
(2, 2, 10, 'No', 8000, 2),
(3, 3, 15, 'Sí', 11000, 3),
(4, 4, 3, 'Sí', 18000, 4),
(5, 5, 7, 'No', 17000, 5),
(6, 6, 12, 'Sí', 23000, 6),
(7, 7, 8, 'No', 20000, 7),
(8, 8, 1, 'Sí', 15000, 8),
(9, 9, 6, 'Sí', 22000, 9),
(10, 10, 9, 'No', 10000, 10),
(11, 11, 11, 'Sí', 19000, 11),
(12, 12, 2, 'No', 12000, 12),
(14, 13, 19, 'No', 25000, 5),
(15, 14, 17, 'Si', 32000, 7),
(16, 15, 18, 'No', 28000, 4),
(17, 16, 15, 'Si', 15000, 8),
(18, 17, 16, 'No', 45000, 2),
(19, 18, 14, 'No', 21000, 3),
(20, 19, 20, 'Si', 37000, 6),
(21, 20, 13, 'No', 29000, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `platillos`
--

CREATE TABLE `platillos` (
  `id_platillo` int(11) NOT NULL,
  `nombre_platillo` varchar(50) DEFAULT NULL,
  `precio_platillo` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `platillos`
--

INSERT INTO `platillos` (`id_platillo`, `nombre_platillo`, `precio_platillo`) VALUES
(1, 'Tamal Chocoano', 15000),
(2, 'Arroz Clavao', 12000),
(3, 'Sancocho de Pescado', 18000),
(4, 'Cazuela de Mariscos', 25000),
(5, 'Pescado Frito con Patacones', 20000),
(6, 'Encocado de Camarón', 22000),
(7, 'Sudado de Piangua', 17000),
(8, 'Arroz con Jaiba', 20000),
(9, 'Torta de Ñame', 10000),
(10, 'Carimañolas de Pescado', 8000),
(11, 'Bocachico en Salsa', 19000),
(12, 'Pusandao', 23000),
(13, 'Empanadas de Piangua', 9000),
(14, 'Bagre en Salsa de Coco', 21000),
(15, 'Torta de Plátano', 11000),
(16, 'Ceviche de Piangua', 16000),
(17, 'Arroz Atollado', 14000),
(18, 'Mojarra en Salsa Criolla', 20000),
(19, 'Bollos de Mazorca', 7000),
(20, 'Postre de Borojó', 12000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reserva`
--

CREATE TABLE `reserva` (
  `id_reserva` int(11) NOT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `tipo_reserva` varchar(50) DEFAULT NULL,
  `fecha_reserva` date DEFAULT NULL,
  `hora_reserva` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `reserva`
--

INSERT INTO `reserva` (`id_reserva`, `id_cliente`, `tipo_reserva`, `fecha_reserva`, `hora_reserva`) VALUES
(1, 1, 'Individual', '2025-02-20', '12:30:00'),
(2, 2, 'Familiar', '2025-02-20', '14:00:00'),
(3, 3, 'dos', '2025-02-21', '10:45:00'),
(4, 4, 'Individual', '2025-02-21', '18:30:00'),
(5, 5, 'Familiar', '2025-02-22', '20:00:00'),
(6, 6, 'cuatros', '2025-02-22', '13:15:00'),
(7, 7, 'Individual', '2025-02-23', '11:45:00'),
(8, 8, 'Familiar', '2025-02-23', '17:00:00'),
(9, 9, 'dos', '2025-02-24', '09:30:00'),
(10, 10, 'Individual', '2025-02-24', '19:15:00'),
(11, 11, 'Familiar', '2025-02-25', '12:00:00'),
(12, 12, 'ochos', '2025-02-25', '15:45:00'),
(13, 13, 'Individual', '2025-02-26', '08:30:00'),
(14, 14, 'Familiar', '2025-02-26', '21:00:00'),
(15, 15, 'dos', '2025-02-27', '16:20:00'),
(16, 16, 'Individual', '2025-02-27', '14:10:00'),
(17, 17, 'Familiar', '2025-02-28', '18:00:00'),
(18, 18, 'individual', '2025-02-28', '11:50:00'),
(19, 19, 'Individual', '2025-02-27', '13:40:00'),
(20, 20, 'Familiar', '2005-02-20', '20:30:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles_empleados`
--

CREATE TABLE `roles_empleados` (
  `id_rol` int(11) NOT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `tipo_rol` varchar(50) DEFAULT NULL,
  `fecha_iniciacion` date DEFAULT NULL,
  `fecha_final` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `roles_empleados`
--

INSERT INTO `roles_empleados` (`id_rol`, `id_empleado`, `tipo_rol`, `fecha_iniciacion`, `fecha_final`) VALUES
(1, 1, 'Mesero', '2023-01-10', '2025-12-31'),
(2, 2, 'Cocinero', '2022-05-15', '2025-12-31'),
(3, 3, 'Administrador', '2021-08-20', '2025-02-20'),
(4, 4, 'Cajero', '2024-02-01', '2026-02-01'),
(5, 5, 'Mesero', '2023-07-10', '2025-07-10'),
(6, 6, 'Chef', '2022-03-25', '2026-03-25'),
(7, 7, 'Ayudante de Cocina', '2023-09-12', '2025-09-12'),
(8, 8, 'Repartidor', '2024-01-05', '2026-01-05'),
(9, 9, 'Encargado de Compras', '2022-06-15', '2026-06-15'),
(10, 10, 'Gerente', '2020-12-01', '2025-02-21'),
(11, 11, 'Bartender', '2023-11-20', '2025-11-20'),
(12, 12, 'Lavaplatos', '2024-04-10', '2026-04-10'),
(13, 13, 'Administrador', '2023-01-15', '2024-01-15'),
(14, 14, 'Recepcionista', '2023-02-20', '2024-02-20'),
(15, 15, 'Médico General', '2023-03-10', '2024-03-10'),
(16, 16, 'Enfermero', '2023-04-05', '2024-04-05'),
(17, 17, 'Técnico de Laboratorio', '2023-05-12', '2024-05-12'),
(18, 18, 'Cirujano', '2023-06-18', '2024-06-18'),
(19, 19, 'Paramédico', '2023-07-22', '2024-07-22'),
(20, 20, 'Conductor de Ambulancia', '2023-08-30', '2024-08-30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `salario_empleados`
--

CREATE TABLE `salario_empleados` (
  `id_salario` int(11) NOT NULL,
  `id_rol` int(11) DEFAULT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `cantidad_salario` int(11) DEFAULT NULL,
  `fecha_salario` date DEFAULT NULL,
  `confirmacion` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `salario_empleados`
--

INSERT INTO `salario_empleados` (`id_salario`, `id_rol`, `id_empleado`, `cantidad_salario`, `fecha_salario`, `confirmacion`) VALUES
(1, 1, 1, 1500000, '2025-03-31', 'Sí'),
(2, 2, 2, 1800000, '2025-03-31', 'Sí'),
(3, 3, 3, 2500000, '2025-03-31', 'Sí'),
(4, 4, 4, 1600000, '2025-03-31', 'Sí'),
(5, 5, 5, 1500000, '2025-03-31', 'Sí'),
(6, 6, 6, 3000000, '2025-03-31', 'Sí'),
(7, 7, 7, 1300000, '2025-03-31', 'Sí'),
(8, 8, 8, 1400000, '2025-03-31', 'Sí'),
(9, 9, 9, 2000000, '2025-03-31', 'Sí'),
(10, 10, 10, 3500000, '2025-03-31', 'Sí'),
(11, 11, 11, 1700000, '2025-03-31', 'Sí'),
(12, 12, 12, 1200000, '2025-03-31', 'Sí');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vistas_clientes_empleadosasc`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vistas_clientes_empleadosasc` (
`nombre_cliente` varchar(50)
,`nombre_empleado` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vistas_clientes_empleadosdesc`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vistas_clientes_empleadosdesc` (
`nombre_cliente` varchar(50)
,`nombre_empleado` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vistas_direccionconlike`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vistas_direccionconlike` (
`direccion` varchar(100)
,`direccion_empleado` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vistas_empleadosyclientes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vistas_empleadosyclientes` (
`id_cliente` int(11)
,`direccion` varchar(100)
,`id_empleado` int(11)
,`direccion_empleado` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vistas_fechas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vistas_fechas` (
`fecha_confirmacion_estado` date
,`fecha_reserva` date
,`fecha_iniciacion` date
,`fecha_final` date
,`fecha_salario` date
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vistas_id`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vistas_id` (
`id_cliente` int(11)
,`id_empleado` int(11)
,`id_estado` int(11)
,`id_mesa` int(11)
,`id_pedido` int(11)
,`id_platillo` int(11)
,`id_reserva` int(11)
,`id_rol` int(11)
,`id_salario` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_clienteencargo`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_clienteencargo` (
`id_cliente` int(11)
,`hora_reserva` varchar(50)
,`fecha_reserva` date
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_cliente_platillo`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_cliente_platillo` (
`nombre_cliente` varchar(50)
,`eleccion` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_empleadocompleto`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_empleadocompleto` (
`id_empleado` int(11)
,`nombre_empleado` varchar(50)
,`tipo_rol` varchar(50)
,`cantidad_salario` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_empleadosalario`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_empleadosalario` (
`nombre_empleado` varchar(50)
,`documento` varchar(50)
,`cantidad_salario` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_empleadosconrol`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_empleadosconrol` (
`nombre_empleado` varchar(50)
,`id_empleado` int(11)
,`tipo_rol` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_empleadosnivelacion`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_empleadosnivelacion` (
`Empleados` varchar(50)
,`cantidad_salario` int(11)
,`nivel_salario` varchar(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_mesas_estado`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_mesas_estado` (
`id_mesa` int(11)
,`mesa_estado` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_mesaypedido`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_mesaypedido` (
`id_mesa` int(11)
,`total_pedidos` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_min_max`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_min_max` (
`salario_maximo` int(11)
,`salario_minimo` int(11)
,`salario_promedio` decimal(14,4)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_numeroreserva`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_numeroreserva` (
`id_cliente` int(11)
,`total_reservas` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_promediosalario`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_promediosalario` (
`id_rol` int(11)
,`salario_promedio` decimal(14,4)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_reservacliente`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_reservacliente` (
`id_cliente` int(11)
,`reserva_clienteTipo` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_totalpedidos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_totalpedidos` (
`id_pedido` int(11)
,`total_salarios` decimal(32,0)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_totalsalarios`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_totalsalarios` (
`id_empleado` int(11)
,`total_salario` decimal(32,0)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vistas_clientes_empleadosasc`
--
DROP TABLE IF EXISTS `vistas_clientes_empleadosasc`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vistas_clientes_empleadosasc`  AS SELECT `clientes`.`nombre_cliente` AS `nombre_cliente`, `empleados`.`nombre_empleado` AS `nombre_empleado` FROM (`clientes` join `empleados` on(`clientes`.`id_cliente` = `empleados`.`id_empleado`)) ORDER BY `clientes`.`nombre_cliente` DESC, `empleados`.`nombre_empleado` DESC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vistas_clientes_empleadosdesc`
--
DROP TABLE IF EXISTS `vistas_clientes_empleadosdesc`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vistas_clientes_empleadosdesc`  AS SELECT `clientes`.`nombre_cliente` AS `nombre_cliente`, `empleados`.`nombre_empleado` AS `nombre_empleado` FROM (`clientes` join `empleados` on(`clientes`.`id_cliente` = `empleados`.`id_empleado`)) ORDER BY `clientes`.`nombre_cliente` ASC, `empleados`.`nombre_empleado` ASC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vistas_direccionconlike`
--
DROP TABLE IF EXISTS `vistas_direccionconlike`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vistas_direccionconlike`  AS SELECT `clientes`.`direccion` AS `direccion`, `empleados`.`direccion_empleado` AS `direccion_empleado` FROM (`clientes` join `empleados` on(`clientes`.`id_cliente` = `empleados`.`id_empleado`)) WHERE `clientes`.`direccion` like 's%' OR `empleados`.`direccion_empleado` like 's%' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vistas_empleadosyclientes`
--
DROP TABLE IF EXISTS `vistas_empleadosyclientes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vistas_empleadosyclientes`  AS SELECT `clientes`.`id_cliente` AS `id_cliente`, `clientes`.`direccion` AS `direccion`, `empleados`.`id_empleado` AS `id_empleado`, `empleados`.`direccion_empleado` AS `direccion_empleado` FROM (`clientes` join `empleados` on(`clientes`.`id_cliente` = `empleados`.`id_empleado`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vistas_fechas`
--
DROP TABLE IF EXISTS `vistas_fechas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vistas_fechas`  AS SELECT `estado`.`fecha_confirmacion_estado` AS `fecha_confirmacion_estado`, `reserva`.`fecha_reserva` AS `fecha_reserva`, `roles_empleados`.`fecha_iniciacion` AS `fecha_iniciacion`, `roles_empleados`.`fecha_final` AS `fecha_final`, `salario_empleados`.`fecha_salario` AS `fecha_salario` FROM (((`estado` join `reserva` on(`estado`.`id_estado` = `reserva`.`id_reserva`)) join `roles_empleados` on(`estado`.`id_estado` = `roles_empleados`.`id_rol`)) join `salario_empleados` on(`estado`.`id_estado` = `salario_empleados`.`id_salario`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vistas_id`
--
DROP TABLE IF EXISTS `vistas_id`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vistas_id`  AS SELECT `clientes`.`id_cliente` AS `id_cliente`, `empleados`.`id_empleado` AS `id_empleado`, `estado`.`id_estado` AS `id_estado`, `mesa`.`id_mesa` AS `id_mesa`, `pedidos`.`id_pedido` AS `id_pedido`, `platillos`.`id_platillo` AS `id_platillo`, `reserva`.`id_reserva` AS `id_reserva`, `roles_empleados`.`id_rol` AS `id_rol`, `salario_empleados`.`id_salario` AS `id_salario` FROM ((((((((`clientes` join `empleados` on(`clientes`.`id_cliente` = `empleados`.`id_empleado`)) join `estado` on(`clientes`.`id_cliente` = `estado`.`id_estado`)) join `mesa` on(`clientes`.`id_cliente` = `mesa`.`id_mesa`)) join `pedidos` on(`clientes`.`id_cliente` = `pedidos`.`id_pedido`)) join `platillos` on(`clientes`.`id_cliente` = `platillos`.`id_platillo`)) join `reserva` on(`clientes`.`id_cliente` = `reserva`.`id_reserva`)) join `roles_empleados` on(`clientes`.`id_cliente` = `roles_empleados`.`id_rol`)) join `salario_empleados` on(`clientes`.`id_cliente` = `salario_empleados`.`id_salario`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_clienteencargo`
--
DROP TABLE IF EXISTS `vista_clienteencargo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_clienteencargo`  AS SELECT `clientes`.`id_cliente` AS `id_cliente`, `reserva`.`hora_reserva` AS `hora_reserva`, `reserva`.`fecha_reserva` AS `fecha_reserva` FROM (`clientes` join `reserva` on(`clientes`.`id_cliente` = `reserva`.`id_reserva`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_cliente_platillo`
--
DROP TABLE IF EXISTS `vista_cliente_platillo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_cliente_platillo`  AS SELECT `clientes`.`nombre_cliente` AS `nombre_cliente`, `platillos`.`nombre_platillo` AS `eleccion` FROM (`clientes` join `platillos` on(`clientes`.`id_cliente` = `platillos`.`id_platillo`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_empleadocompleto`
--
DROP TABLE IF EXISTS `vista_empleadocompleto`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_empleadocompleto`  AS SELECT `empleados`.`id_empleado` AS `id_empleado`, `empleados`.`nombre_empleado` AS `nombre_empleado`, `roles_empleados`.`tipo_rol` AS `tipo_rol`, `salario_empleados`.`cantidad_salario` AS `cantidad_salario` FROM ((`empleados` join `roles_empleados` on(`empleados`.`id_empleado` = `roles_empleados`.`id_rol`)) join `salario_empleados` on(`empleados`.`id_empleado` = `salario_empleados`.`id_salario`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_empleadosalario`
--
DROP TABLE IF EXISTS `vista_empleadosalario`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_empleadosalario`  AS SELECT `empleados`.`nombre_empleado` AS `nombre_empleado`, `empleados`.`documento` AS `documento`, `salario_empleados`.`cantidad_salario` AS `cantidad_salario` FROM (`empleados` join `salario_empleados` on(`empleados`.`id_empleado` = `salario_empleados`.`id_salario`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_empleadosconrol`
--
DROP TABLE IF EXISTS `vista_empleadosconrol`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_empleadosconrol`  AS SELECT `empleados`.`nombre_empleado` AS `nombre_empleado`, `empleados`.`id_empleado` AS `id_empleado`, `roles_empleados`.`tipo_rol` AS `tipo_rol` FROM (`empleados` join `roles_empleados` on(`empleados`.`id_empleado` = `roles_empleados`.`id_rol`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_empleadosnivelacion`
--
DROP TABLE IF EXISTS `vista_empleadosnivelacion`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_empleadosnivelacion`  AS SELECT `empleados`.`nombre_empleado` AS `Empleados`, `salario_empleados`.`cantidad_salario` AS `cantidad_salario`, CASE WHEN `salario_empleados`.`cantidad_salario` >= 2500000 THEN 'Alto' WHEN `salario_empleados`.`cantidad_salario` >= 1500000 AND `salario_empleados`.`cantidad_salario` < 2500000 THEN 'Medio' WHEN `salario_empleados`.`cantidad_salario` < 1500000 THEN 'bajo' ELSE 'sin salario' END AS `nivel_salario` FROM (`empleados` join `salario_empleados` on(`empleados`.`id_empleado` = `salario_empleados`.`id_salario`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_mesas_estado`
--
DROP TABLE IF EXISTS `vista_mesas_estado`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_mesas_estado`  AS SELECT `mesa`.`id_mesa` AS `id_mesa`, `estado`.`estado` AS `mesa_estado` FROM (`mesa` join `estado` on(`mesa`.`id_mesa` = `estado`.`id_estado`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_mesaypedido`
--
DROP TABLE IF EXISTS `vista_mesaypedido`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_mesaypedido`  AS SELECT `mesa`.`id_mesa` AS `id_mesa`, count(`pedidos`.`id_pedido`) AS `total_pedidos` FROM (`pedidos` join `mesa` on(`pedidos`.`id_pedido` = `mesa`.`id_mesa`)) GROUP BY `mesa`.`id_mesa` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_min_max`
--
DROP TABLE IF EXISTS `vista_min_max`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_min_max`  AS SELECT max(`salario_empleados`.`cantidad_salario`) AS `salario_maximo`, min(`salario_empleados`.`cantidad_salario`) AS `salario_minimo`, avg(`salario_empleados`.`cantidad_salario`) AS `salario_promedio` FROM `salario_empleados` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_numeroreserva`
--
DROP TABLE IF EXISTS `vista_numeroreserva`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_numeroreserva`  AS SELECT `clientes`.`id_cliente` AS `id_cliente`, count(`reserva`.`id_reserva`) AS `total_reservas` FROM (`clientes` join `reserva` on(`clientes`.`id_cliente` = `reserva`.`id_cliente`)) GROUP BY `clientes`.`id_cliente` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_promediosalario`
--
DROP TABLE IF EXISTS `vista_promediosalario`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_promediosalario`  AS SELECT `roles_empleados`.`id_rol` AS `id_rol`, avg(`salario_empleados`.`cantidad_salario`) AS `salario_promedio` FROM ((`empleados` join `roles_empleados` on(`empleados`.`id_empleado` = `roles_empleados`.`id_empleado`)) join `salario_empleados` on(`empleados`.`id_empleado` = `salario_empleados`.`id_empleado`)) GROUP BY `roles_empleados`.`id_rol` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_reservacliente`
--
DROP TABLE IF EXISTS `vista_reservacliente`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_reservacliente`  AS SELECT `clientes`.`id_cliente` AS `id_cliente`, `reserva`.`tipo_reserva` AS `reserva_clienteTipo` FROM (`clientes` join `reserva` on(`clientes`.`id_cliente` = `reserva`.`id_reserva`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_totalpedidos`
--
DROP TABLE IF EXISTS `vista_totalpedidos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_totalpedidos`  AS SELECT `pedidos`.`id_pedido` AS `id_pedido`, sum(`salario_empleados`.`cantidad_salario`) AS `total_salarios` FROM (`salario_empleados` join `pedidos` on(`pedidos`.`id_pedido` = `salario_empleados`.`id_salario`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_totalsalarios`
--
DROP TABLE IF EXISTS `vista_totalsalarios`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_totalsalarios`  AS SELECT `empleados`.`id_empleado` AS `id_empleado`, sum(`salario_empleados`.`cantidad_salario`) AS `total_salario` FROM (`empleados` join `salario_empleados` on(`empleados`.`id_empleado` = `salario_empleados`.`id_salario`)) ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`id_empleado`);

--
-- Indices de la tabla `estado`
--
ALTER TABLE `estado`
  ADD PRIMARY KEY (`id_estado`),
  ADD KEY `id_reserva` (`id_reserva`),
  ADD KEY `id_mesa` (`id_mesa`);

--
-- Indices de la tabla `mesa`
--
ALTER TABLE `mesa`
  ADD PRIMARY KEY (`id_mesa`),
  ADD KEY `id_reserva` (`id_reserva`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `id_empleado` (`id_empleado`),
  ADD KEY `id_platillo` (`id_platillo`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- Indices de la tabla `platillos`
--
ALTER TABLE `platillos`
  ADD PRIMARY KEY (`id_platillo`);

--
-- Indices de la tabla `reserva`
--
ALTER TABLE `reserva`
  ADD PRIMARY KEY (`id_reserva`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- Indices de la tabla `roles_empleados`
--
ALTER TABLE `roles_empleados`
  ADD PRIMARY KEY (`id_rol`),
  ADD KEY `id_empleado` (`id_empleado`);

--
-- Indices de la tabla `salario_empleados`
--
ALTER TABLE `salario_empleados`
  ADD PRIMARY KEY (`id_salario`),
  ADD KEY `id_rol` (`id_rol`),
  ADD KEY `id_empleado` (`id_empleado`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `empleados`
--
ALTER TABLE `empleados`
  MODIFY `id_empleado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `estado`
--
ALTER TABLE `estado`
  MODIFY `id_estado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `mesa`
--
ALTER TABLE `mesa`
  MODIFY `id_mesa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `platillos`
--
ALTER TABLE `platillos`
  MODIFY `id_platillo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `reserva`
--
ALTER TABLE `reserva`
  MODIFY `id_reserva` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT de la tabla `roles_empleados`
--
ALTER TABLE `roles_empleados`
  MODIFY `id_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `salario_empleados`
--
ALTER TABLE `salario_empleados`
  MODIFY `id_salario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `estado`
--
ALTER TABLE `estado`
  ADD CONSTRAINT `estado_ibfk_1` FOREIGN KEY (`id_reserva`) REFERENCES `reserva` (`id_reserva`),
  ADD CONSTRAINT `estado_ibfk_2` FOREIGN KEY (`id_mesa`) REFERENCES `mesa` (`id_mesa`);

--
-- Filtros para la tabla `mesa`
--
ALTER TABLE `mesa`
  ADD CONSTRAINT `mesa_ibfk_1` FOREIGN KEY (`id_reserva`) REFERENCES `reserva` (`id_reserva`);

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id_empleado`),
  ADD CONSTRAINT `pedidos_ibfk_2` FOREIGN KEY (`id_platillo`) REFERENCES `platillos` (`id_platillo`),
  ADD CONSTRAINT `pedidos_ibfk_3` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`);

--
-- Filtros para la tabla `reserva`
--
ALTER TABLE `reserva`
  ADD CONSTRAINT `reserva_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`);

--
-- Filtros para la tabla `roles_empleados`
--
ALTER TABLE `roles_empleados`
  ADD CONSTRAINT `roles_empleados_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id_empleado`);

--
-- Filtros para la tabla `salario_empleados`
--
ALTER TABLE `salario_empleados`
  ADD CONSTRAINT `salario_empleados_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `roles_empleados` (`id_rol`),
  ADD CONSTRAINT `salario_empleados_ibfk_2` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id_empleado`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
