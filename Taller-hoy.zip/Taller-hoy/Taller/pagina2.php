<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Procedimientos Almacenados</title>
    <link rel="stylesheet" href="css/pagina2.css">
</head>
<body>
    <h2>Ejecutar Procedimientos Almacenados</h2>
    <form action="" method="POST">
        <label for="procedimiento">Seleccione un procedimiento:</label>
        <select name="procedimiento" id="procedimiento">
            <option value="ActualizarStock">Actualizar Stock</option>
            <option value="AplicarCupon">Aplicar Cupón</option>
            <option value="CrearOrden">Crear Orden</option>
            <option value="GenerarReporteVentas">Generar Reporte de Ventas</option>
            <option value="ObtenerProductosCategoria">Obtener Productos por Categoría</option>
        </select>
        <br><br>
        <label for="param1">Parámetro 1:</label>
        <input type="text" name="param1" id="param1">
        <br><br>
        <label for="param2">Parámetro 2 (Opcional):</label>
        <input type="text" name="param2" id="param2">
        <br><br>
        <button type="submit" name="ejecutar">Ejecutar</button>
        <a href="index.php">regreso</a>
    </form>

    <div id="resultado">
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "commerce";

            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Conexión fallida: " . $conn->connect_error);
            }

            $procedimiento = $_POST["procedimiento"];
            $param1 = !empty($_POST["param1"]) ? $_POST["param1"] : NULL;
            $param2 = !empty($_POST["param2"]) ? $_POST["param2"] : NULL;

            // Validaciones
            if ($procedimiento == "AplicarCupon" && ($param1 === NULL || $param2 === NULL)) {
                echo "<p style='color: red;'>Error: Se requieren ID de orden y descuento.</p>";
            } else {
                // Llamada a los procedimientos almacenados
                if ($param1 !== NULL && $param2 !== NULL) {
                    $stmt = $conn->prepare("CALL $procedimiento(?, ?)");
                    $stmt->bind_param("id", $param1, $param2);
                } elseif ($param1 !== NULL) {
                    $stmt = $conn->prepare("CALL $procedimiento(?)");
                    $stmt->bind_param("i", $param1);
                } else {
                    echo "<p style='color: red;'>Error: Faltan parámetros para ejecutar el procedimiento.</p>";
                    exit;
                }

                if ($stmt->execute()) {
                    echo "<p style='color: green;'>Procedimiento ejecutado correctamente.</p>";
                } else {
                    echo "<p style='color: red;'>Error al ejecutar el procedimiento: " . $stmt->error . "</p>";
                }

                $stmt->close();
            }
            $conn->close();
        }
        ?>
    </div>
</body>
</html>
