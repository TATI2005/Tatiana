-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 27-03-2025 a las 23:02:19
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `commerce`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarStock` (IN `p_producto_id` INT, IN `p_cantidad` INT)   BEGIN
    UPDATE Productos 
    SET stock = stock + p_cantidad
    WHERE id = p_producto_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AplicarCupon` (IN `p_orden_id` INT, IN `p_descuento` DECIMAL(10,2))   BEGIN
    UPDATE Ordenes 
    SET total = GREATEST(total - p_descuento, 0)
    WHERE id = p_orden_id;

    UPDATE Productos 
    SET precio = GREATEST(precio - p_descuento, 0)
    WHERE id IN (SELECT id FROM Productos);
    SELECT id AS Orden_ID, total AS Total_Con_Descuento FROM Ordenes WHERE id = p_orden_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `CrearOrden` (IN `p_usuario_id` INT)   BEGIN
    DECLARE new_order_id INT;

    -- Insertar la orden con total en 0 inicialmente
    INSERT INTO Ordenes (usuario_id, fecha, estado, total) 
    VALUES (p_usuario_id, NOW(), 'Pendiente', 0);

    -- Obtener el ID de la orden recién creada
    SET new_order_id = LAST_INSERT_ID();

    -- Retornar el ID de la nueva orden
    SELECT new_order_id AS orden_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GenerarReporteVentas` (IN `p_fecha_inicio` DATE, IN `p_fecha_fin` DATE)   BEGIN
    SELECT * FROM Ventas WHERE fecha_venta >= p_fecha_inicio AND fecha_venta <= p_fecha_fin;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerProductosCategoria` (IN `p_categoria_id` INT)   BEGIN
    SELECT * FROM Productos WHERE categoria_id = p_categoria_id;
END$$

--
-- Funciones
--
CREATE DEFINER=`root`@`localhost` FUNCTION `AplicarImpuesto` (`p_monto` DECIMAL(10,2), `p_impuesto_id` INT) RETURNS DECIMAL(10,2) DETERMINISTIC BEGIN
    DECLARE v_tasa DECIMAL(5,2);
    SELECT tasa INTO v_tasa FROM Impuestos WHERE id = p_impuesto_id;
    RETURN p_monto + (p_monto * v_tasa / 100);
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `CalcularTotalOrden` (`ordenId` INT) RETURNS DECIMAL(10,2) DETERMINISTIC BEGIN
DECLARE total DECIMAL(10, 2);
SELECT SUM(cantidad * precio_unitario) INTO total
FROM Detalles_Orden
WHERE orden_id = ordenId;
RETURN total;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `ObtenerNombreUsuario` (`usuario_id` INT) RETURNS VARCHAR(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci DETERMINISTIC BEGIN
    DECLARE nombre_usuario VARCHAR(255);

    SELECT nombre INTO nombre_usuario FROM usuarios WHERE id = usuario_id;

    RETURN nombre_usuario;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(1, 'Electrónica'),
(2, 'Ropa'),
(3, 'Hogar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `direccion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `nombre`, `email`, `telefono`, `direccion`) VALUES
(1, 'Luis Rojas', 'luis@example.com', '3201234567', 'Calle 50 #10-20, Bogotá'),
(2, 'María Fernández', 'maria@example.com', '3212345678', 'Av. Siempre Viva #742, Medellín'),
(3, 'Carlos Sánchez', 'carlos@example.com', '3223456789', 'Cra. 20 #15-30, Cali');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras_proveedores`
--

CREATE TABLE `compras_proveedores` (
  `id` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_compra` decimal(10,2) NOT NULL,
  `fecha_compra` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `compras_proveedores`
--

INSERT INTO `compras_proveedores` (`id`, `proveedor_id`, `producto_id`, `cantidad`, `precio_compra`, `fecha_compra`) VALUES
(1, 1, 1, 20, 1100.00, '2025-03-15'),
(2, 2, 2, 100, 18.00, '2025-03-16'),
(3, 3, 3, 30, 140.00, '2025-03-17');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `configuracion_sitio`
--

CREATE TABLE `configuracion_sitio` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `valor` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `configuracion_sitio`
--

INSERT INTO `configuracion_sitio` (`id`, `nombre`, `valor`) VALUES
(1, 'Nombre Sitio', 'Mi Tienda Online'),
(2, 'Moneda', 'COP'),
(3, 'Impuesto Aplicable', 'IVA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cupones`
--

CREATE TABLE `cupones` (
  `id` int(11) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `descuento` decimal(5,2) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cupones`
--

INSERT INTO `cupones` (`id`, `codigo`, `descuento`, `fecha_inicio`, `fecha_fin`) VALUES
(2, 'ENVIOGRATIS', 100.00, '2025-03-15', '2025-04-15'),
(3, 'PROMO5', 5.00, '2025-03-20', '2025-04-10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamentos_empleados`
--

CREATE TABLE `departamentos_empleados` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `departamentos_empleados`
--

INSERT INTO `departamentos_empleados` (`id`, `nombre`) VALUES
(1, 'Ventas'),
(2, 'Soporte Técnico'),
(3, 'Administración');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_orden`
--

CREATE TABLE `detalles_orden` (
  `orden_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalles_orden`
--

INSERT INTO `detalles_orden` (`orden_id`, `producto_id`, `cantidad`, `precio_unitario`) VALUES
(1, 1, 1, 1200.00),
(2, 2, 3, 20.50),
(3, 3, 2, 150.00);

--
-- Disparadores `detalles_orden`
--
DELIMITER $$
CREATE TRIGGER `before_insert_detalles_orden` BEFORE INSERT ON `detalles_orden` FOR EACH ROW BEGIN
    UPDATE Productos 
    SET stock = stock - NEW.cantidad 
    WHERE id = NEW.producto_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direcciones_usuarios`
--

CREATE TABLE `direcciones_usuarios` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `direccion` text NOT NULL,
  `ciudad` varchar(100) NOT NULL,
  `codigo_postal` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `direcciones_usuarios`
--

INSERT INTO `direcciones_usuarios` (`id`, `usuario_id`, `direccion`, `ciudad`, `codigo_postal`) VALUES
(1, 1, 'Calle A #123', 'Bogotá', '110111'),
(2, 2, 'Av. B #456', 'Medellín', '050021'),
(3, 3, 'Cra. C #789', 'Cali', '760033');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `cargo` varchar(100) NOT NULL,
  `salario` decimal(10,2) NOT NULL,
  `fecha_contratacion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`id`, `nombre`, `cargo`, `salario`, `fecha_contratacion`) VALUES
(1, 'Pedro Gómez', 'Gerente', 5000.00, '2024-01-10'),
(2, 'Laura Martínez', 'Vendedor', 2500.00, '2024-02-20'),
(3, 'Andrés Castro', 'Soporte Técnico', 3000.00, '2024-03-15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `envios`
--

CREATE TABLE `envios` (
  `id` int(11) NOT NULL,
  `orden_id` int(11) DEFAULT NULL,
  `direccion` text NOT NULL,
  `ciudad` varchar(100) NOT NULL,
  `codigo_postal` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `envios`
--

INSERT INTO `envios` (`id`, `orden_id`, `direccion`, `ciudad`, `codigo_postal`) VALUES
(1, 1, 'Calle 123, Bogotá', 'Bogotá', '110111'),
(2, 2, 'Av. Central 456, Medellín', 'Medellín', '050021'),
(3, 3, 'Cra. 789, Cali', 'Cali', '760033');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_precios`
--

CREATE TABLE `historial_precios` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `precio_anterior` decimal(10,2) NOT NULL,
  `precio_nuevo` decimal(10,2) NOT NULL,
  `fecha_cambio` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `historial_precios`
--

INSERT INTO `historial_precios` (`id`, `producto_id`, `precio_anterior`, `precio_nuevo`, `fecha_cambio`) VALUES
(1, 1, 1300.00, 1200.00, '2025-03-20 00:00:00'),
(2, 2, 22.00, 20.50, '2025-03-22 00:00:00'),
(3, 3, 160.00, 150.00, '2025-03-23 00:00:00'),
(4, 1, 1200.00, 1180.00, '2025-03-26 00:00:00'),
(5, 1, 1180.00, 2200.00, '2025-03-26 00:00:00'),
(6, 1, 2200.00, 2196.67, '2025-03-26 00:00:00'),
(7, 2, 20.50, 17.17, '2025-03-26 00:00:00'),
(8, 3, 150.00, 146.67, '2025-03-26 00:00:00'),
(9, 1, 2196.67, 2193.34, '2025-03-26 00:00:00'),
(10, 2, 17.17, 13.84, '2025-03-26 00:00:00'),
(11, 3, 146.67, 143.34, '2025-03-26 00:00:00'),
(12, 1, 2193.34, 2173.34, '2025-03-26 00:00:00'),
(13, 2, 13.84, 0.00, '2025-03-26 00:00:00'),
(14, 3, 143.34, 123.34, '2025-03-26 00:00:00'),
(15, 2, 0.00, 20.00, '2025-03-26 00:00:00'),
(16, 1, 2173.34, 2153.34, '2025-03-26 00:00:00'),
(17, 2, 20.00, 0.00, '2025-03-26 00:00:00'),
(18, 3, 123.34, 103.34, '2025-03-26 00:00:00'),
(19, 1, 2153.34, 2148.34, '2025-03-26 00:00:00'),
(20, 3, 103.34, 98.34, '2025-03-26 00:00:00'),
(21, 1, 2148.34, 2143.34, '2025-03-26 00:00:00'),
(22, 3, 98.34, 93.34, '2025-03-26 00:00:00'),
(23, 2, 0.00, 20.00, '2025-03-26 00:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenes_productos`
--

CREATE TABLE `imagenes_productos` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `imagenes_productos`
--

INSERT INTO `imagenes_productos` (`id`, `producto_id`, `url`) VALUES
(1, 1, 'https://www.google.com/aclk?sa=l&ai=DChsSEwjE1svj06iMAxW0nloFHSO8PEIYACICCAEQDRoCdnU&co=1&gclid=Cj0KCQjwy46_BhDOARIsAIvmcwON9_lZO1oiAWsS9_B6nJaOrPYgRDXIxvfU3c3ATOuiBPgl7uNVdM8aAmTnEALw_wcB&sig=AOD64_3DNKTvUss_X43NGdc3SjyhkLQmHA&ctype=5&q=&ved=2ahUKEwj7zcbj06iMAxVxSzABHdMEEkQQ9aACKAB6BAgCEEY&adurl='),
(2, 2, 'https://www.google.com/imgres?q=camiseta&imgurl=https%3A%2F%2Fvansco.vteximg.com.br%2Farquivos%2Fids%2F340545-1000-1000%2FVN00088MBLK-2.jpg%3Fv%3D638551011682670000&imgrefurl=https%3A%2F%2Fwww.vans.com.co%2Fcamiseta-manga-corta-negra-vans-classic-ni%25C3%25B1os-vn000ivfy28%2Fp&docid=TxQhT43pF9v1aM&tbnid=jI8FS4D_HTkVAM&vet=12ahUKEwiu9_2_1KiMAxWuQzABHcrhLRcQM3oECFgQAA..i&w=1000&h=1000&hcb=2&ved=2ahUKEwiu9_2_1KiMAxWuQzABHcrhLRcQM3oECFgQAA'),
(3, 3, 'https://www.google.com/aclk?sa=l&ai=DChsSEwjdqZvX1KiMAxX_gFoFHZm6CwwYACICCAEQBRoCdnU&co=1&gclid=Cj0KCQjwy46_BhDOARIsAIvmcwPd9D435N7Z39KRVVqMox3IovSVyf0xRq-zBISwsUR93kZwaJV1PGwaAsAjEALw_wcB&sig=AOD64_0NyHBgX9lhuYPBKHmOdTniPMgFbQ&ctype=5&q=&ved=2ahUKEwjzspbX1KiMAxV5STABHZdAE3wQ9aACKAB6BAgEECc&adurl=');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `impuestos`
--

CREATE TABLE `impuestos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tasa` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `impuestos`
--

INSERT INTO `impuestos` (`id`, `nombre`, `tasa`) VALUES
(1, 'IVA', 19.00),
(2, 'Impuesto al lujo', 10.00),
(3, 'Eco impuesto', 5.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `ubicacion` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`id`, `producto_id`, `cantidad`, `ubicacion`) VALUES
(1, 1, 10, 'Bodega Central'),
(2, 2, 50, 'Tienda Medellín'),
(3, 3, 15, 'Bodega Cali');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_sistema`
--

CREATE TABLE `logs_sistema` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `accion` text NOT NULL,
  `tabla_afectada` varchar(100) NOT NULL,
  `fecha_hora` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `logs_sistema`
--

INSERT INTO `logs_sistema` (`id`, `usuario_id`, `accion`, `tabla_afectada`, `fecha_hora`) VALUES
(1, 1, 'Inserción de orden', 'Ordenes', '2025-03-26 10:30:00'),
(2, 2, 'Modificación de stock', 'Productos', '2025-03-26 11:00:00'),
(3, 3, 'Eliminación de cuenta', 'Usuarios', '2025-03-26 12:15:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ordenes`
--

CREATE TABLE `ordenes` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `estado` varchar(50) NOT NULL,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ordenes`
--

INSERT INTO `ordenes` (`id`, `usuario_id`, `fecha`, `estado`, `total`) VALUES
(1, 1, '2025-03-26 10:30:00', 'Pendiente', 0.00),
(2, 2, '2025-03-26 11:00:00', 'Enviado', 0.00),
(3, 3, '2025-03-26 12:15:00', 'Entregado', 0.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE `pagos` (
  `id` int(11) NOT NULL,
  `orden_id` int(11) DEFAULT NULL,
  `monto` decimal(10,2) NOT NULL,
  `metodo_pago` varchar(50) NOT NULL,
  `fecha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pagos`
--

INSERT INTO `pagos` (`id`, `orden_id`, `monto`, `metodo_pago`, `fecha`) VALUES
(1, 1, 1139.00, 'Tarjeta de crédito', '2025-03-26 10:45:00'),
(2, 2, 61.50, 'PayPal', '2025-03-26 11:10:00'),
(3, 3, 300.00, 'Transferencia bancaria', '2025-03-26 12:30:00');

--
-- Disparadores `pagos`
--
DELIMITER $$
CREATE TRIGGER `after_insert_pagos` AFTER INSERT ON `pagos` FOR EACH ROW BEGIN
    UPDATE Ordenes 
    SET estado = 'Pagada' 
    WHERE id = NEW.orden_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `categoria_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `descripcion`, `precio`, `stock`, `categoria_id`) VALUES
(1, 'Laptop', 'Laptop de última generación', 2143.34, 160, 1),
(2, 'Camiseta', 'Camiseta de algodón 100%', 20.00, 105, 2),
(3, 'Silla de oficina', 'Silla ergonómica con ajuste lumbar', 93.34, 15, 3);

--
-- Disparadores `productos`
--
DELIMITER $$
CREATE TRIGGER `after_update_productos` AFTER UPDATE ON `productos` FOR EACH ROW BEGIN
    IF OLD.precio <> NEW.precio THEN
        INSERT INTO Historial_Precios (producto_id, precio_anterior, precio_nuevo, fecha_cambio) 
        VALUES (NEW.id, OLD.precio, NEW.precio, '2025-03-26');
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `contacto` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`id`, `nombre`, `contacto`, `telefono`) VALUES
(1, 'Tech Supplier', 'Carlos Mendoza', '3001234567'),
(2, 'Fashion Distributors', 'Ana Torres', '3012345678'),
(3, 'Muebles y Más', 'Juan López', '3023456789');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `calificacion` int(11) NOT NULL,
  `comentario` text DEFAULT NULL,
  `fecha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reviews`
--

INSERT INTO `reviews` (`id`, `producto_id`, `usuario_id`, `calificacion`, `comentario`, `fecha`) VALUES
(1, 1, 1, 5, 'Excelente laptop, muy rápida', '2025-03-26 13:00:00'),
(2, 2, 2, 4, 'Buena calidad, pero la talla es un poco grande', '2025-03-26 13:30:00'),
(3, 3, 3, 5, 'Muy cómoda, perfecta para largas horas de trabajo', '2025-03-26 14:00:00');

--
-- Disparadores `reviews`
--
DELIMITER $$
CREATE TRIGGER `after_insert_reviews` AFTER INSERT ON `reviews` FOR EACH ROW BEGIN
    UPDATE Productos 
    SET precio = (SELECT AVG(calificacion) FROM Reviews WHERE producto_id = NEW.producto_id)
    WHERE id = NEW.producto_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesiones_usuarios`
--

CREATE TABLE `sesiones_usuarios` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `token` text NOT NULL,
  `fecha_inicio` datetime NOT NULL,
  `fecha_fin` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `sesiones_usuarios`
--

INSERT INTO `sesiones_usuarios` (`id`, `usuario_id`, `token`, `fecha_inicio`, `fecha_fin`) VALUES
(1, 1, 'abc123', '2025-03-26 08:00:00', '2025-03-26 12:00:00'),
(2, 2, 'def456', '2025-03-26 09:30:00', '2025-03-26 13:30:00'),
(3, 3, 'ghi789', '2025-03-26 10:15:00', '2025-03-26 14:15:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `Contraseña` varchar(100) NOT NULL,
  `rol` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `email`, `Contraseña`, `rol`) VALUES
(1, 'Juan Pérez', 'juan@example.com', '', 'Cliente'),
(2, 'Ana Gómez', 'ana@example.com', '', 'Administrador'),
(3, 'Carlos Ruiz', 'carlos@example.com', '', 'Vendedor');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id` int(11) NOT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_venta` decimal(10,2) NOT NULL,
  `fecha_venta` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id`, `cliente_id`, `producto_id`, `cantidad`, `precio_venta`, `fecha_venta`) VALUES
(1, 1, 1, 1, 1250.00, '2025-03-10 09:00:00'),
(2, 2, 2, 2, 22.50, '2025-03-12 14:30:00'),
(3, 3, 3, 1, 155.00, '2025-03-14 16:45:00');

--
-- Disparadores `ventas`
--
DELIMITER $$
CREATE TRIGGER `after_insert_ventas` AFTER INSERT ON `ventas` FOR EACH ROW BEGIN
    UPDATE Inventario 
    SET cantidad = cantidad - NEW.cantidad 
    WHERE producto_id = NEW.producto_id;
END
$$
DELIMITER ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indices de la tabla `compras_proveedores`
--
ALTER TABLE `compras_proveedores`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proveedor_id` (`proveedor_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `configuracion_sitio`
--
ALTER TABLE `configuracion_sitio`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cupones`
--
ALTER TABLE `cupones`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo` (`codigo`);

--
-- Indices de la tabla `departamentos_empleados`
--
ALTER TABLE `departamentos_empleados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `detalles_orden`
--
ALTER TABLE `detalles_orden`
  ADD PRIMARY KEY (`orden_id`,`producto_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `direcciones_usuarios`
--
ALTER TABLE `direcciones_usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `envios`
--
ALTER TABLE `envios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orden_id` (`orden_id`);

--
-- Indices de la tabla `historial_precios`
--
ALTER TABLE `historial_precios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `imagenes_productos`
--
ALTER TABLE `imagenes_productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `impuestos`
--
ALTER TABLE `impuestos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `logs_sistema`
--
ALTER TABLE `logs_sistema`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `ordenes`
--
ALTER TABLE `ordenes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orden_id` (`orden_id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoria_id` (`categoria_id`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `producto_id` (`producto_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `sesiones_usuarios`
--
ALTER TABLE `sesiones_usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `compras_proveedores`
--
ALTER TABLE `compras_proveedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `configuracion_sitio`
--
ALTER TABLE `configuracion_sitio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `cupones`
--
ALTER TABLE `cupones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `departamentos_empleados`
--
ALTER TABLE `departamentos_empleados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `direcciones_usuarios`
--
ALTER TABLE `direcciones_usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `empleados`
--
ALTER TABLE `empleados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `envios`
--
ALTER TABLE `envios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `historial_precios`
--
ALTER TABLE `historial_precios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `imagenes_productos`
--
ALTER TABLE `imagenes_productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `impuestos`
--
ALTER TABLE `impuestos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `inventario`
--
ALTER TABLE `inventario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `logs_sistema`
--
ALTER TABLE `logs_sistema`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `ordenes`
--
ALTER TABLE `ordenes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `pagos`
--
ALTER TABLE `pagos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `sesiones_usuarios`
--
ALTER TABLE `sesiones_usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `compras_proveedores`
--
ALTER TABLE `compras_proveedores`
  ADD CONSTRAINT `compras_proveedores_ibfk_1` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`),
  ADD CONSTRAINT `compras_proveedores_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `detalles_orden`
--
ALTER TABLE `detalles_orden`
  ADD CONSTRAINT `detalles_orden_ibfk_1` FOREIGN KEY (`orden_id`) REFERENCES `ordenes` (`id`),
  ADD CONSTRAINT `detalles_orden_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `direcciones_usuarios`
--
ALTER TABLE `direcciones_usuarios`
  ADD CONSTRAINT `direcciones_usuarios_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `envios`
--
ALTER TABLE `envios`
  ADD CONSTRAINT `envios_ibfk_1` FOREIGN KEY (`orden_id`) REFERENCES `ordenes` (`id`);

--
-- Filtros para la tabla `historial_precios`
--
ALTER TABLE `historial_precios`
  ADD CONSTRAINT `historial_precios_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `imagenes_productos`
--
ALTER TABLE `imagenes_productos`
  ADD CONSTRAINT `imagenes_productos_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `logs_sistema`
--
ALTER TABLE `logs_sistema`
  ADD CONSTRAINT `logs_sistema_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `ordenes`
--
ALTER TABLE `ordenes`
  ADD CONSTRAINT `ordenes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`orden_id`) REFERENCES `ordenes` (`id`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`);

--
-- Filtros para la tabla `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`),
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `sesiones_usuarios`
--
ALTER TABLE `sesiones_usuarios`
  ADD CONSTRAINT `sesiones_usuarios_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  ADD CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
