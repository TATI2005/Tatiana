<?php
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli("localhost", "root", "", "db_granja");

    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];
    $telefono = $_POST["telefono"];
    $tipo = $_POST["tipo_usuario"];
    $contrasena = $_POST["contrasena"];
    $confirmar = $_POST["confirmar_contrasena"];

    if ($contrasena !== $confirmar) {
        $mensaje = "Las contraseñas no coinciden.";
    } else {
        $contrasena_encriptada = hash("sha256", $contrasena); // ENCRIPTAMOS CON SHA-256

        // Verificar si el correo ya existe
        $verificar = $conn->prepare("SELECT * FROM usuario WHERE correo = ?");
        $verificar->bind_param("s", $correo);
        $verificar->execute();
        $resultado = $verificar->get_result();

        if ($resultado->num_rows > 0) {
            $mensaje = "El correo ya está registrado.";
        } else {
            $stmt = $conn->prepare("INSERT INTO usuario (nombre, correo, telefono, Tipo_usuario, contraseña, bloqueado) VALUES (?, ?, ?, ?, ?, 0)");
            $stmt->bind_param("sssss", $nombre, $correo, $telefono, $tipo, $contrasena_encriptada);

            if ($stmt->execute()) {
                $mensaje = "Usuario registrado con éxito.";
            } else {
                $mensaje = "Error al registrar usuario.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="stylo2.css">
</head>
<body>
    <form method="POST">
        <?php if (!empty($mensaje)): ?>
            <p class="mensaje-error"><?php echo $mensaje; ?></p>
        <?php endif; ?>

        <h2>Registro</h2>
        <input type="text" name="nombre" placeholder="Nombre completo" required>
        <input type="email" name="correo" placeholder="Correo electrónico" required>
        <input type="text" name="telefono" placeholder="Teléfono" required>
        <select name="tipo_usuario" required>
            <option value="">Seleccionar tipo de usuario</option>
            <option value="Administrador">Administrador</option>
            <option value="Granjero">Granjero</option>
            <option value="Vendendor">Vendendor</option>
        </select>
        <input type="password" name="contrasena" placeholder="Contraseña" required>
        <input type="password" name="confirmar_contrasena" placeholder="Confirmar contraseña" required>
        <button type="submit">Registrarse</button>
        <a href="index.php">¿Ya tienes cuenta? Inicia sesión</a>
    </form>
</body>
</html>
