<?php
session_start();
$tiempoRestante = 0;
$bloqueado = false;
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli("localhost", "root", "", "db_granja");

    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    $correo = $_POST["correo"];
    $contrasena = $_POST["contrasena"];

    $stmt = $conn->prepare("SELECT Id_usuario, contraseña, bloqueado FROM usuario WHERE correo = ?");
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $fila = $resultado->fetch_assoc();
        $usuarioId = $fila["Id_usuario"];

        if ($fila["bloqueado"] == 1) {
            $checkTiempo = $conn->prepare("
                SELECT MAX(fecha_intento) AS ultima_falla 
                FROM intentos_login 
                WHERE Id_usuario = ? AND Exitoso = 0
            ");
            $checkTiempo->bind_param("i", $usuarioId);
            $checkTiempo->execute();
            $tiempo = $checkTiempo->get_result()->fetch_assoc();

            $ultimaFalla = strtotime($tiempo["ultima_falla"]);
            $ahora = time();
            $tiempoRestante = max(0, 180 - ($ahora - $ultimaFalla)); // 180 = 3 minutos

            if ($tiempoRestante <= 0) {
                $conn->query("UPDATE usuario SET bloqueado = 0 WHERE Id_usuario = $usuarioId");
                $fila["bloqueado"] = 0;
                $bloqueado = false;
            } else {
                $bloqueado = true;
                $mensaje = "Usuario bloqueado. Intenta nuevamente en " . ceil($tiempoRestante / 60) . " minutos.";
            }
        }

        if ($fila["bloqueado"] == 0) {
            // Compara la contraseña escrita con la versión hash en la base de datos
            if ($fila["contraseña"] === hash('sha256', $contrasena)) {
                $_SESSION["usuario_id"] = $fila["Id_usuario"];
                $conn->query("INSERT INTO intentos_login (Id_usuario, Exitoso) VALUES ($usuarioId, 1)");
                header("Location: ../Granja_completo/Inicio.php");
                exit;
            } else {
                $conn->query("INSERT INTO intentos_login (Id_usuario, Exitoso) VALUES ($usuarioId, 0)");

                $checkIntentos = $conn->prepare("
                    SELECT COUNT(*) AS intentos 
                    FROM intentos_login 
                    WHERE Id_usuario = ? AND Exitoso = 0 
                    AND fecha_intento > NOW() - INTERVAL 3 MINUTE
                ");
                $checkIntentos->bind_param("i", $usuarioId);
                $checkIntentos->execute();
                $resultadoIntentos = $checkIntentos->get_result()->fetch_assoc();

                if ($resultadoIntentos["intentos"] >= 3) {
                    $conn->query("UPDATE usuario SET bloqueado = 1 WHERE Id_usuario = $usuarioId");
                    $mensaje = "Usuario bloqueado por 3 minutos.";
                    $bloqueado = true;
                    $tiempoRestante = 180;
                } else {
                    $mensaje = "Contraseña incorrecta.";
                }
            }
        }
    } else {
        $mensaje = "Usuario no encontrado.";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Login Granja</title>
    <link rel="stylesheet" href="stylo2.css">
</head>

<body>
    <form method="POST">
        <?php if (!empty($mensaje)): ?>
            <p class="mensaje-error"><?php echo $mensaje; ?></p>
        <?php endif; ?>

        <h2>Iniciar Sesión</h2>
        <input type="email" name="correo" placeholder="Correo" required>
        <input type="password" name="contrasena" placeholder="Contraseña" required>
        <button id="entrar" type="submit" <?php if ($bloqueado) echo "disabled"; ?>>Entrar</button>
        <a href="registro1.php">Registrarse</a>
    </form>

    <?php if ($bloqueado): ?>
        <script>
            let tiempo = <?php echo $tiempoRestante; ?>; // tiempo restante en segundos
            const boton = document.getElementById("entrar");

            const intervalo = setInterval(() => {
                tiempo--;
                if (tiempo <= 0) {
                    boton.disabled = false;
                    clearInterval(intervalo);
                }
            }, 1000);
        </script>
    <?php endif; ?>
</body>

</html>