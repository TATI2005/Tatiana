<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CRUD DE GRANJA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <h1 class="bg-dark p-3 text-light text-center">CRUD MYSQLI</h1>
    <br>
    <div class="container">
        <div class="container text-dark bg-light p-3 border border-dark rounded-2">
            <h1>Lista de Usuarios</h1><br>
            <table class="table">
                <thead class="table-primary">
                    <tr>
                        <th scope="col">Id_usuario</th>
                        <th scope="col">Usuario</th>
                        <th scope="col">Correo</th>
                        <th scope="col">Telefono</th>
                        <th scope="col">Contraseña</th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include("conexion.php");
                    $sql = "SELECT * FROM usuario";
                    $query = mysqli_query($conexion, $sql);

                    while ($fila = mysqli_fetch_array($query)) {
                    ?>
                        <tr>
                            <th scope="row"><?php echo $fila['Id_usuario'] ?></th>
                            <th scope="row"><?php echo $fila['Usuario'] ?></th>
                            <th scope="row"><?php echo $fila['Correo'] ?></th>
                            <th scope="row"><?php echo $fila['Telefono'] ?></th>
                            <th scope="row"><?php echo $fila['Contraseña'] ?></th>
                            <th scope="row">
                                <a class="btn btn-success" href="Editardato.php?Id_usuario=<?php echo $fila['Id_usuario']; ?>">Editar datos</a>
                                <a class="btn btn-danger" href="Eliminardato.php?Id_usuario=<?php echo $fila['Id_usuario']; ?>">Eliminar datos</a>
                            </th>
                        </tr>
                    <?php
                    }
                    ?>

                </tbody>
            </table>
        </div><br>
        <div class="container">
            <a class="btn btn-primary text-light" href="AgregraUsuario.php">Agregrar</a>
            <a class="btn btn-dark text-light" href="Pagina.php">Regreso</a><br><br>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>