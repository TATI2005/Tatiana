<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD</title>
    <link rel="stylesheet" href="CSS/pagina1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body><br>
    <h1 class="titulo">ELija una opcion:</h1>
    <div class="container">
        <section>
            <button class="usuario">
                <h2><a href="index.php" class="usuario"><i class="fa-solid fa-user"></i>usuarios</a></h2>
            </button><br><br>
            <button class="animales">
                <h2><a href="index2.php" class="animales" ><i class="fa-brands fa-bluesky"></i>Animales</a></h2>
            </button>
        </section>
    </div><br><br>
    <a class="salir" href="../Granja_completo/Inicio.php">Regreso</a><br><br>
</body>

</html>