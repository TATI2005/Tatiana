<?php
include('conexion.php');
    $Id_animal = $_REQUEST['Id_animal'];
    $sql = "SELECT * FROM animales WHERE Id_animal = '$Id_animal'";
    $query = mysqli_query($conexion, $sql);
    $fila = mysqli_fetch_array($query);
?>

<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar Animal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <h1 class="bg-dark p-3 text-light text-center">Editar Animal</h1><br><br>
    <div class="container">
        <form action="Editar2.php" method="POST">
            <input type="hidden" name="Id_animal" value="<?php echo $fila['Id_animal']; ?>">
            <div class="mb-3">
                <label class="form-label">ID del Animal</label>
                <input type="text" class="form-control" placeholder="Id_animal" name="Id_animal" value="<?php echo $fila['Id_animal']; ?>"><br>
                <label class="form-label">Tipo de Animal</label>
                <input type="text" class="form-control" placeholder="Tipo_animal" name="Tipo_animal" value="<?php echo $fila['Tipo_animal']; ?>"><br>
                <label class="form-label">Talla</label>
                <input type="text" class="form-control" placeholder="Talla" name="Talla" value="<?php echo $fila['Talla']; ?>"><br>
                <label class="form-label">Peso</label>
                <input type="text" class="form-control" placeholder="Peso" name="Peso" value="<?php echo $fila['Peso']; ?>"><br>
                <label class="form-label">Edad</label>
                <input type="text" class="form-control" placeholder="Edad" name="Edad" value="<?php echo $fila['Edad']; ?>"><br>
                <label class="form-label">Cantidad</label>
                <input type="text" class="form-control" placeholder="Cantidad" name="Cantidad" value="<?php echo $fila['Cantidad']; ?>"><br>
                <label class="form-label">Dueño del Animal</label>
                <input type="text" class="form-control" placeholder="Dueño_animal" name="Dueño_animal" value="<?php echo $fila['Dueño_animal']; ?>"><br>
            </div><br>
            <div class="container">
                <button type="submit" class="btn btn-primary">Editar Animal</button>
                <a class="btn btn-dark" href="index2.php">Regresar</a>
            </div>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>