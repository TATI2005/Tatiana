<?php 
    include('conexion.php');

    $Id_animal = $_POST['Id_animal'];
    $Tipo_animal = $_POST['Tipo_animal'];
    $Talla = $_POST['Talla'];
    $Peso = $_POST['Peso'];
    $Edad = $_POST['Edad'];
    $Cantidad = $_POST['Cantidad'];
    $Dueño_animal = $_POST['Dueño_animal'];

    $sql = "INSERT INTO animales (Id_animal, Tipo_animal, Talla, Peso, Edad, Cantidad, Dueño_animal) 
    VALUES('$Id_animal', '$Tipo_animal', '$Talla', '$Peso', '$Edad', '$Cantidad', '$Dueño_animal')";
    $query = mysqli_query($conexion, $sql);


    if($query === TRUE){
        header("Location: index2.php");
    }


?>