<?php
include('conexion.php');
$Id_usuario = $_REQUEST['Id_usuario'];
$sql = "SELECT * FROM usuario WHERE Id_usuario = '$Id_usuario'";
$query = mysqli_query($conexion, $sql);
$fila = mysqli_fetch_array($query);

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <h1 class="bg-dark p-3 text-light text-center">Editar Usuario</h1><br><br>
    <div class="container">
        <form action="Editar.php" method="POST">
            <input type="hidden" name="Id_usuario" value="<?php echo 
            $fila['Id_usuario']?>">
            <div class="mb-3">
                <label class="form-label">Id_usuario</label>
                <input type="text" class="form-control" placeholder="Id_usuario" name="Id_usuario" Value="<?php echo $fila['Id_usuario']; ?>"><br>
                <label class="form-label">Usuario</label>
                <input type="text" class="form-control" placeholder="Usuario" name="Usuario" Value="<?php echo $fila['Usuario']; ?>"><br>
                <label class="form-label">Correo</label>
                <input type="text" class="form-control" placeholder="Correo" name="Correo" Value="<?php echo $fila['Correo']; ?>"><br>
                <label class="form-label">Telefono</label>
                <input type="tel" class="form-control" placeholder="Telefono" name="Telefono" Value="<?php echo $fila['Telefono']; ?>"><br>
                <label class="form-label">Contraseña</label>
                <input type="text" class="form-control" placeholder="Contraseña" name="Contraseña" Value="<?php echo $fila['Contraseña']; ?>"><br>
            </div><br>
            <div class="container">
                <button type="submit" class="btn btn-primary">Editar usuario</button>
                <a class="btn btn-dark" href="index.php">regresar</a>
            </div>

        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>