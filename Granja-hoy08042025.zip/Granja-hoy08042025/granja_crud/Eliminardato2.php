<?php 
    include('conexion.php');
    $Id_animal = $_REQUEST['Id_animal'];
    $sql = "DELETE FROM animales WHERE Id_animal='$Id_animal'";
    $query = mysqli_query($conexion, $sql);

    if($query){
        header("Location: index2.php");
    }
?>