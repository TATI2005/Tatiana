<?php
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "granja"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tipo_animal = $_POST["Tipo_animal"];
    $talla = $_POST["Talla"];
    $peso = floatval($_POST["Peso"]);
    $edad = intval($_POST["Edad"]);
    $cantidad = intval($_POST["Cantidad"]);
    $dueño_animal = isset($_POST["Dueño_animal"]) ? $_POST["Dueño_animal"] : '';

    $sql = "INSERT INTO animales (Tipo_animal, Talla, Peso, Edad, Cantidad, Dueño_animal) 
            VALUES (?, ?, ?, ?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ssdiis", $tipo_animal, $talla, $peso, $edad, $cantidad, $dueño_animal);

        if ($stmt->execute()) {
            echo "<script>alert('Registro guardado con éxito'); window.location.href='Saludos.php';</script>";
        } else {
            echo "<script>alert('Error al guardar: " . $stmt->error . "'); window.history.back();</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('Error en la preparación de la consulta.'); window.history.back();</script>";
    }
}

$conn->close();
?>



$conn->close();
?>
