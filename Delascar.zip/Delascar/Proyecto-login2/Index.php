<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesion en un supermercado</title>
    <link rel="stylesheet" href="Css/style1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body><br>
    
    <form action="Iniciarsesion.php" method="POST">
    <a href="index.php"><img src="Img/FUCLA.png"></a>
        <h2>Iniciar Sesion Estudiante</h2>
        <hr>
        <?php
            if(isset($_GET['error'])){
        ?>
        <p class="error">
            <?php 
            echo $_GET['error'];
            ?>
        </p>
        <?php
            }
        ?>
        <hr><br>
        <i class="fa-solid fa-user"></i>
        <label>Usuario</label>
        <input type="text" name="Usuario" placeholder="Nombre de usuario">
        
        <i class="fa-solid fa-unlock"></i>
        <label>Contraseña</label>
        <input type="password" name="Contraseña" placeholder="Ingrese su contraseña"><br><br>
        <hr><hr><br>
        
        <button type="submit">Iniciar Sesion</button>
        <a  target="_blank" href="CrearCuenta.php">Crear Cuenta</a>
    </form><br>
</body>
</html>
