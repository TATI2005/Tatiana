<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Crear Cuenta</title>
  <link rel="stylesheet" href="Css/registro1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
   
</head>
<body><br>
  <form action="Registrarse.php" method="POST"><br>
    <a href="Index.php"><img class="imagen" src="Img/Fucla.png" alt="Descripción de la imagen"></a><br>
    <center><h1 class="Titulo">Crear Cuenta</h1></center>
    <hr>
    <?php if(isset($_GET['error'])): ?>
    <div class="chat-error">
        <?php echo htmlspecialchars($_GET['error']); ?>
    </div>
    <?php endif; ?>
    
    
    <label for="nombre">
    <i class="fa-solid fa-user"></i>
        Usuario:</label>
    <input type="text" name="nombre" placeholder="Crea un nombre de usuario" required>

    <label for="nombre_completo">
    <i class="fa-solid fa-user"></i>
        Nombre Completo:</label>
    <input type="text" name="nombre_completo" placeholder="Nombre completo" required>

    <label for="nombre_completo">
    <i class="fa-solid fa-envelope"></i>
        correo:</label>
    <input type="email" name="correo" placeholder="ingrese su correo eletronico" required>

    <label for="contraseña">
    <i class="fa-solid fa-Key"></i>
        Contraseña:</label>
    <input type="password" name="contraseña" placeholder="Ingrese una contraseña" required>

    <label for="confirmar_contraseña">
    <i class="fa-solid fa-user"></i>
        Confirmar Contraseña:</label>
    <input type="password" name="confirmar_contraseña" placeholder="Repita la contraseña" required><br>

    <hr><br>

    <button type="submit">Crear Cuenta</button>
    <a target="_blank" href="Index.php">Volver al Inicio</a><br>
  </form><br>
  <br>
</body>
</html>
