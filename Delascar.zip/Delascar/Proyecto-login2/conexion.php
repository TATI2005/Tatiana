<?php
    $host = "localhost";
    $User = "root";
    $Pass = "";
    $db = "login2";

    $conexion = mysqli_connect($host, $User, $Pass, $db);

    if(!$conexion){
        echo "Conexión fallida";
    }
?>
