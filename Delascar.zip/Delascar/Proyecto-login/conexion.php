<?php
    $host = "localhost";
    $User = "root";
    $Pass = "";
    $db = "login";

    $conexion = mysqli_connect($host, $User, $Pass, $db);

    if(!$conexion){
        echo "Conexión fallida";
    }
?>
