<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Document</title>
    <link rel="stylesheet" href="Css/inicio.css">
</head>
<body>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supermercado</title>
</head>
<body>
    <div class="navbar">
    <a href="index.php"><img src="Img/descarga.jpg"></a>
        <a href="#">Inicio</a>
        <a href="#">Servicios</a>
        <a href="#">Productos</a>
        <a href="#">Acerca de</a>
        <a href="#">Contacto</a>
        <a href="Cerrar_Sesion.php" class="btn btn-white">Cerrar Sesión</a>
    </div><br><br><br>

    <center><h1>¡Bienvenido Comprador!</h1></center>
</body>
</html>