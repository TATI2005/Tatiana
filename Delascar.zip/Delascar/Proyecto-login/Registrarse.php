<?php
    include('conexion.php');
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        $nombre = $_POST['nombre'];
        $nombre_completo = $_POST['nombre_completo'];
        $correo = $_POST['correo'];
        $contraseña = $_POST['contraseña'];
        $confirmar_contraseña = $_POST['confirmar_contraseña'];

        if (empty($nombre) || empty($nombre_completo)||empty($correo) || empty($contraseña) || empty($confirmar_contraseña)) {
            echo "<p>Todos los campos son obligatorios.</p>";
        } 
        else if ($contraseña !== $confirmar_contraseña) {
            echo "<p>Las contraseñas no coinciden.</p>";
        } 
        else {
            $sql_check = "SELECT * FROM usuarios WHERE Usuario = ?";
            $stmt = $conexion->prepare($sql_check);
            $stmt->bind_param('s', $nombre);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                echo "<p>El nombre de usuario ya está registrado.</p>";
            } 
            else {
                // Guarda la contraseña sin encriptar (no recomendado)
                $sql_insert = "INSERT INTO usuarios (Usuario, Nombre_Completo, Correo_electronico, Contraseña) VALUES (?, ?, ?, ?)";
                $stmt = $conexion->prepare($sql_insert);
                $stmt->bind_param('ssss', $nombre, $nombre_completo, $correo, $contraseña);                

                if ($stmt->execute()) {
                    echo "<p>Cuenta creada exitosamente. Serás redirigido al <a href='Index.php'>inicio de sesión</a>.</p>";
                    header("refresh:2;url=Index.php"); 
                    exit();
                } 
                else {
                    echo "<p>Error al crear la cuenta: " . $stmt->error . "</p>";
                }
            }
        }
    }
?>
