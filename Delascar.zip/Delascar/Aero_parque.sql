CREATE TABLE `areas_parqueo` (
  `id_area` int PRIMARY KEY AUTO_INCREMENT,
  `nombre_area` varchar(100),
  `capacidad` int
);

CREATE TABLE `clientes` (
  `cod_clt` int PRIMARY KEY AUTO_INCREMENT,
  `nombre_clt` varchar(100),
  `direccion_clt` text
);

CREATE TABLE `empleados` (
  `cod_emp` int PRIMARY KEY AUTO_INCREMENT,
  `nombre_emp` varchar(100),
  `telefono_emp` char(12)
);

CREATE TABLE `categorias_medicamento` (
  `cod_cat` int PRIMARY KEY AUTO_INCREMENT,
  `nombrec` varchar(30)
);

CREATE TABLE `medicamento` (
  `cod_med` int PRIMARY KEY AUTO_INCREMENT,
  `nombrem` varchar(30),
  `preciom` decimal NOT NULL DEFAULT 0,
  `stockm` int NOT NULL DEFAULT 0,
  `fecha_vencimiento` date,
  `cod_cat` int
);

CREATE TABLE `venta` (
  `nro_venta` int PRIMARY KEY AUTO_INCREMENT,
  `fecha` datetime,
  `cod_clt` int,
  `cod_emp` int
);

CREATE TABLE `detalle_venta` (
  `nro_venta` int,
  `cod_med` int,
  `cantidadv` smallint,
  `preciov` decimal,
  PRIMARY KEY(`nro_venta`, `cod_med`)
);

ALTER TABLE `medicamento` ADD FOREIGN KEY (`cod_cat`) REFERENCES `categorias_medicamento` (`cod_cat`);
ALTER TABLE `venta` ADD FOREIGN KEY (`cod_clt`) REFERENCES `clientes` (`cod_clt`);
ALTER TABLE `venta` ADD FOREIGN KEY (`cod_emp`) REFERENCES `empleados` (`cod_emp`);
ALTER TABLE `detalle_venta` ADD FOREIGN KEY (`nro_venta`) REFERENCES `venta` (`nro_venta`);
ALTER TABLE `detalle_venta` ADD FOREIGN KEY (`cod_med`) REFERENCES `medicamento` (`cod_med`);
