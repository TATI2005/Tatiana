<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "commerce2";


$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$resultado = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tipo = $_POST["tipo"];

    switch ($tipo) {
        case "VerificarOrdenActiva":
            $orden_id = intval($_POST["orden_id"]);
            $sql = "CALL VerificarOrdenActiva($orden_id)";
            break;
        case "InsertarUsuario":
            $nombre = $_POST["nombre"];
            $email = $_POST["email"];
            $contraseña = $_POST["contraseña"];
            $rol = $_POST["rol"];
            $sql = "CALL InsertarUsuario('$nombre', '$email', '$contraseña', '$rol')";
            break;
        case "ReembolsarOrden":
            $orden_id = intval($_POST["orden_id"]);
            $sql = "CALL ReembolsarOrden($orden_id)";
            break;
        case "ObtenerProductosConCalificacion":
            $sql = "CALL ObtenerProductosConCalificacion()";
            break;
        case "CalcularTotalOrden":
            $orden_id = intval($_POST["orden_id"]);
            $sql = "SELECT CalcularTotalOrden($orden_id) AS total";
            break;
        case "ObtenerNombreUsuario":
            $usuario_id = intval($_POST["usuario_id"]);
            $sql = "SELECT ObtenerNombreUsuario($usuario_id) AS nombre";
            break;
        case "calcular_monto_con_impuesto":
            $impuesto_id = intval($_POST["impuesto_id"]);
            $monto = floatval($_POST["monto"]);
            $sql = "SELECT calcular_monto_con_impuesto($impuesto_id, $monto) AS total_con_impuesto";
            break;
        case "ActualizarStock":
            $producto_id = intval($_POST["producto_id"]);
            $cantidad = intval($_POST["cantidad"]);
            $sql = "CALL ActualizarStock($producto_id, $cantidad)";
            break;
        case "AplicarCupon":
            $orden_id = intval($_POST["orden_id"]);
            $codigo_cupon = $_POST["codigo_cupon"];
            $sql = "CALL AplicarCupon($orden_id, '$codigo_cupon')";
            break;
        case "CrearOrden":
            $usuario_id = intval($_POST["usuario_id"]);
            $producto_id = intval($_POST["producto_id"]);
            $cantidad = intval($_POST["cantidad"]);
            $sql = "CALL CrearOrden($usuario_id, $producto_id, $cantidad)";
            break;
        case "GenerarReporteVentas":
            $fecha_inicio = $_POST["fecha_inicio"];
            $fecha_fin = $_POST["fecha_fin"];
            $sql = "CALL GenerarReporteVentas('$fecha_inicio', '$fecha_fin')";
            break;
        case "ObtenerProductosCategoria":
            $categoria_id = intval($_POST["categoria_id"]);
            $sql = "CALL ObtenerProductosCategoria($categoria_id)";
            break;
        default:
            die("Opción no válida");
    }

    if ($result = $conn->query($sql)) {
        if ($result instanceof mysqli_result) {
            $row = $result->fetch_assoc();
            $resultado = json_encode($row);
        } else {
            $resultado = "Operación ejecutada correctamente";
        }
    } else {
        $resultado = "Error al ejecutar la consulta: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejecutar Procedimientos y Funciones</title>
    <link rel="stylesheet" href="style1.css">
</head>

<body><br>
    <h1>Seleccione una acción</h1>
    <form action="" method="post">
        <label for="tipo">Elige una opción:</label><br>
        <select name="tipo" id="tipo" onchange="mostrarCampos()">
            <option value="">Seleccione...</option>
            <option value="VerificarOrdenActiva">Verificar Orden Activa</option>
            <option value="InsertarUsuario">Insertar Usuario</option>
            <option value="ReembolsarOrden">Reembolsar Orden</option>
            <option value="ObtenerProductosConCalificacion">Obtener Productos con Calificación</option>
            <option value="CalcularTotalOrden">Calcular Total de Orden</option>
            <option value="ObtenerNombreUsuario">Obtener Nombre de Usuario</option>
            <option value="calcular_monto_con_impuesto">Calcular Monto con Impuesto</option>
            <option value="ActualizarStock">Actualizar Stock</option>
            <option value="AplicarCupon">Aplicar Cupón</option>
            <option value="CrearOrden">Crear Orden</option>
            <option value="GenerarReporteVentas">Generar Reporte de Ventas</option>
            <option value="ObtenerProductosCategoria">Obtener Productos por Categoría</option>
        </select>

        <div id="campos"></div>
        <button type="submit">Ejecutar</button><br>
    </form>
    <h2>Resultado:</h2>
    <div id="resultado">
        <?php
        if ($resultado != "") {
            echo "<pre>" . $resultado . "</pre>";
        }
        ?>
    </div>
    <a href="index.php" id="regrese">Regreso</a>

    <script>
        function mostrarCampos() {
            let tipo = document.getElementById("tipo").value;
            let camposDiv = document.getElementById("campos");
            let camposHTML = "";

            switch (tipo) {
                case "VerificarOrdenActiva":
                case "ReembolsarOrden":
                case "CalcularTotalOrden":
                    camposHTML = '<br><label>ID Orden: <input type="number" name="orden_id" required></label><br>';
                    break;
                case "InsertarUsuario":
                    camposHTML = `
                    <label>Nombre: <input type="text" name="nombre" required></label><br>
                    <label>Email: <input type="email" name="email" required></label><br>
                    <label>Contraseña: <input type="password" name="contraseña" required></label><br>
                    <label>Rol: 
                            <select name="rol" required>
                                <option value="">Selecciona un rol</option>
                                <option value="Cliente">Cliente</option>
                                <option value="Vendedor">Vendedor</option>
                                <option value="Administrador">Administrador</option>
                            </select>
                    </label><br>`;
                    break;
                case "ObtenerNombreUsuario":
                    camposHTML = '<br><label>ID Usuario: <input type="number" name="usuario_id" required></label><br>';
                    break;
                case "calcular_monto_con_impuesto":
                    camposHTML = '<br><label>ID Impuesto: <input type="number" name="impuesto_id" required></label><br>' +
                        '<label>Monto: <input type="number" step="0.01" name="monto" required></label><br><br>';
                    break;
                case "ActualizarStock":
                    camposHTML = '<br><label>ID Producto: <input type="number" name="producto_id" required></label><br>' +
                        '<label>Cantidad: <input type="number" name="cantidad" required></label><br>';
                    break;
                case "AplicarCupon":
                    camposHTML = '<br><label>ID Orden: <input type="number" name="orden_id" required></label><br>' +
                        '<label>Código de Cupón: <input type="text" name="codigo_cupon" required></label><br>';
                    break;
                case "CrearOrden":
                    camposHTML = '<br><label>ID Usuario: <input type="number" name="usuario_id" required></label><br>' +
                        '<label>ID Producto: <input type="number" name="producto_id" required></label><br>' +
                        '<label>Cantidad: <input type="number" name="cantidad" required></label><br>';
                    break;
                case "GenerarReporteVentas":
                    camposHTML = '<br><label>Fecha Inicio: <input type="date" name="fecha_inicio" required></label><br>' +
                        '<label>Fecha Fin: <input type="date" name="fecha_fin" required></label><br>';
                    break;
                case "ObtenerProductosCategoria":
                    camposHTML = '<br><label>ID Categoría: <input type="number" name="categoria_id" required></label><br>';
                    break;
            }

            camposDiv.innerHTML = camposHTML;
        }
    </script>
</body>

</html>