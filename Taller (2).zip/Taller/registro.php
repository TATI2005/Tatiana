<?php
include("conexion1.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["registrar"])) {
    $nombre = trim($_POST["Nombre"]);
    $email = trim($_POST["Email"]);
    $contrasena = $_POST["Contraseña"];
    $confirmar = $_POST["Confirmar"];
    $rol = $_POST["Rol"];

    if (empty($nombre) || empty($email) || empty($contrasena) || empty($confirmar) || empty($rol)) {
        echo "<script>alert('Por favor completa todos los campos'); window.location.href='registro.php';</script>";
        exit();
    }

    if ($contrasena !== $confirmar) {
        echo "<script>alert('Las contraseñas no coinciden'); window.location.href='registro.php';</script>";
        exit();
    }
    $verificar_sql = "SELECT * FROM usuarios WHERE Email = ?";
    $stmt = $conexion->prepare($verificar_sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        echo "<script>alert('Ya existe un usuario con ese correo'); window.location.href='registro.php';</script>";
        exit();
    }
    $insertar_sql = "INSERT INTO usuarios (Nombre, Email, Contraseña, Rol) VALUES (?, ?, ?, ?)";
    $stmt = $conexion->prepare($insertar_sql);
    $stmt->bind_param("ssss", $nombre, $email, $contrasena, $rol);

    if ($stmt->execute()) {
        echo "<script>alert('Registro exitoso'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('Error al registrar: " . $stmt->error . "'); window.location.href='registro.php';</script>";
    }

    $stmt->close();
    $conexion->close();
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Registro</title>
    <link rel="stylesheet" href="css/estilo1.css">
</head>

<body>
    <form action="registro.php" method="post">
        <h2>Registro de Usuario</h2>

        <input type="text" name="Nombre" placeholder="Nombre completo" required>
        <input type="email" name="Email" placeholder="Correo electrónico" required>
        <input type="password" name="Contraseña" placeholder="Contraseña" required>
        <input type="password" name="Confirmar" placeholder="Confirmar contraseña" required><br>

        <select name="Rol" required>
            <option value="">Selecciona un rol</option>
            <option value="Cliente">Cliente</option>
            <option value="Vendedor">Vendedor</option>
            <option value="Administrador">Administrador</option>
        </select>

        <input id="registrarse" type="submit" name="registrar" value="Registrarse">
        <p>¿Ya tienes una cuenta?</p>
        <a href="index.php">Inicia sesión</a>
    </form>
</body>

</html>