<?php
$conexion = new mysqli("localhost", "root", "", "commerce2");

if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}
?>
