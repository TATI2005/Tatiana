<?php
include("conexion1.php");

if (isset($_POST["login"])) {
    $email = $_POST["email"];
    $contrasena = $_POST["contrasena"];

    $sql = "SELECT * FROM usuarios WHERE email='$email' AND contraseña='$contrasena'";
    $resultado = $conexion->query($sql);

    if ($resultado->num_rows == 1) {
        session_start();
        $usuario = $resultado->fetch_assoc();
        $_SESSION["usuario"] = $usuario;
        header("Location: pagina.php");
        exit();
    } else {
        $error = "Correo o contraseña incorrectos.";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>

<body>
    <form action="index.php" method="post">
        <h2>Iniciar Sesión</h2>
        <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <input type="email" name="email" placeholder="Correo electrónico" required>
        <input type="password" name="contrasena" placeholder="Contraseña" required>
        <input id="entrar" type="submit" name="login" value="Entrar">
        <p>¿No tienes cuenta?</p>
        <a href="registro.php">Regístrate</a>
        
    </form>
</body>

</html>