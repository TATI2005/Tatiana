CREATE TABLE `usuarios` (
  `id_usuario` int PRIMARY KEY AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `rol` varchar(20) NOT NULL
);

CREATE TABLE `vehiculos` (
  `id_vehiculo` int PRIMARY KEY AUTO_INCREMENT,
  `placa` varchar(10) UNIQUE NOT NULL,
  `marca` varchar(30),
  `modelo` varchar(30)
);

CREATE TABLE `entradas_salidas` (
  `id_movimiento` int PRIMARY KEY AUTO_INCREMENT,
  `id_vehiculo` int NOT NULL,
  `id_usuario_responsable` int,
  `fecha_entrada` datetime DEFAULT CURRENT_TIMESTAMP,
  `fecha_salida` datetime DEFAULT null
);

ALTER TABLE `entradas_salidas` ADD FOREIGN KEY (`id_vehiculo`) REFERENCES `vehiculos` (`id_vehiculo`);

ALTER TABLE `entradas_salidas` ADD FOREIGN KEY (`id_usuario_responsable`) REFERENCES `usuarios` (`id_usuario`);