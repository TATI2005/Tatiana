-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 16-03-2025 a las 05:52:47
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `login_granja`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alimentos`
--

CREATE TABLE `alimentos` (
  `Id_alimento` int(11) NOT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_granja` int(11) DEFAULT NULL,
  `Id_ventas` int(11) DEFAULT NULL,
  `Tipo_alimento` varchar(100) DEFAULT NULL,
  `Cantidad_alimento` int(11) DEFAULT NULL,
  `Fecha_alimentacion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `alimentos`
--

INSERT INTO `alimentos` (`Id_alimento`, `Id_animal`, `Id_granja`, `Id_ventas`, `Tipo_alimento`, `Cantidad_alimento`, `Fecha_alimentacion`) VALUES
(1, 101, 1, 1, 'Concentrado para bovinos', 50, '2025-03-10'),
(2, 102, 1, 2, 'Pasto kikuyo', 120, '2025-03-11'),
(3, 201, 2, 3, 'Afrecho de arroz', 80, '2025-03-10'),
(4, 202, 2, 4, 'Salvado de trigo', 60, '2025-03-12'),
(5, 301, 3, 5, 'Maíz molido', 90, '2025-03-11');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `animales`
--

CREATE TABLE `animales` (
  `Id_animal` int(11) NOT NULL,
  `Nombre_cientifico` varchar(100) NOT NULL,
  `Nombre_comun` varchar(100) DEFAULT NULL,
  `Especie` varchar(100) DEFAULT NULL,
  `Edad` int(11) DEFAULT NULL,
  `Cantidad` int(11) NOT NULL,
  `Ubicacion` varchar(255) DEFAULT NULL,
  `Descripcion` text DEFAULT NULL,
  `Usuario_animal` int(11) DEFAULT NULL,
  `Fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `animales`
--

INSERT INTO `animales` (`Id_animal`, `Nombre_cientifico`, `Nombre_comun`, `Especie`, `Edad`, `Cantidad`, `Ubicacion`, `Descripcion`, `Usuario_animal`, `Fecha_registro`) VALUES
(101, 'Bos taurus', 'Vaca Holstein', 'Bovino', 5, 10, 'Lote 1 - Finca El Paraíso', 'Vacas lecheras de alta producción.', 1, '2025-03-13 01:16:28'),
(102, 'Gallus gallus domesticus', 'Gallina criolla', 'Ave', 2, 25, 'Gallinero principal', 'Gallinas criollas ponedoras.', 2, '2025-03-13 01:16:28'),
(201, 'Sus scrofa domesticus', 'Cerdo de engorde', 'Porcino', 1, 15, 'Corral 3', 'Cerdos en etapa de engorde.', 3, '2025-03-13 01:16:28'),
(202, 'Capra aegagrus hircus', 'Cabra Saanen', 'Caprino', 4, 8, 'Establo caprino', 'Cabras productoras de leche.', 1, '2025-03-13 01:16:28'),
(301, 'Columba livia', 'Paloma mensajera', 'Ave', 3, 12, 'Pajarera 2', 'Palomas entrenadas para mensajes y exhibiciones.', 2, '2025-03-13 01:16:28');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `Id_cliente` int(11) NOT NULL,
  `Nombre_cliente` varchar(100) NOT NULL,
  `Correo_cliente` varchar(100) NOT NULL,
  `Telefono_cliente` varchar(20) NOT NULL,
  `Id_animal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`Id_cliente`, `Nombre_cliente`, `Correo_cliente`, `Telefono_cliente`, `Id_animal`) VALUES
(1, 'Carlos Rodríguez', 'carlos.rodriguez@email.com', '+57 3104567890', 101),
(2, 'María Fernanda López', 'maria.lopez@email.com', '+57 3205678901', 102),
(3, 'Juan Camilo Pérez', 'juan.perez@email.com', '+57 3156789012', 201),
(4, 'Andrea González', 'andrea.gonzalez@email.com', '+57 3227890123', 202),
(5, 'Felipe Ramírez', 'felipe.ramirez@email.com', '+57 3008901234', 301);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `diagnostico`
--

CREATE TABLE `diagnostico` (
  `Id_diagnostico` int(11) NOT NULL,
  `Id_reporte` int(11) DEFAULT NULL,
  `Diagnostico` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `diagnostico`
--

INSERT INTO `diagnostico` (`Id_diagnostico`, `Id_reporte`, `Diagnostico`) VALUES
(1, 1, 'Fiebre aftosa en bovinos'),
(2, 2, 'Deficiencia de calcio en gallinas'),
(3, 3, 'Neumonía en cerdos'),
(4, 4, 'Mastitis en cabras lecheras'),
(5, 5, 'Parásitos intestinales en palomas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_animal`
--

CREATE TABLE `estado_animal` (
  `Id_estado` int(11) NOT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Estado` enum('Sano','Enfermo','Recuperación') DEFAULT NULL,
  `Fecha_registro` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `estado_animal`
--

INSERT INTO `estado_animal` (`Id_estado`, `Id_animal`, `Estado`, `Fecha_registro`) VALUES
(1, 101, 'Sano', '2025-03-10'),
(2, 102, 'Sano', '2025-03-11'),
(3, 201, 'Enfermo', '2025-03-10'),
(4, 202, 'Recuperación', '2025-03-12'),
(5, 301, 'Sano', '2025-03-11');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evento`
--

CREATE TABLE `evento` (
  `Id_evento` int(11) NOT NULL,
  `Id_historial` int(11) DEFAULT NULL,
  `Tipo_evento` varchar(100) DEFAULT NULL,
  `Fecha_registro` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `evento`
--

INSERT INTO `evento` (`Id_evento`, `Id_historial`, `Tipo_evento`, `Fecha_registro`) VALUES
(1, 1, 'Vacunación bovinos', '2025-03-10'),
(2, 2, 'Desparasitación aves', '2025-03-11'),
(3, 3, 'Control veterinario cerdos', '2025-03-12'),
(4, 4, 'Revisión nutricional cabras', '2025-03-13'),
(5, 5, 'Limpieza y desinfección de corrales', '2025-03-14');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `granja`
--

CREATE TABLE `granja` (
  `Id_granja` int(11) NOT NULL,
  `Id_usuario` int(11) DEFAULT NULL,
  `Telefono_granja` int(11) DEFAULT NULL,
  `Correo` varchar(50) DEFAULT NULL,
  `Direccion` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `granja`
--

INSERT INTO `granja` (`Id_granja`, `Id_usuario`, `Telefono_granja`, `Correo`, `Direccion`) VALUES
(1, 1, 2147483647, 'granja_el_paraiso@email.com', 'Vereda La Esperanza, Antioquia'),
(2, 2, 2147483647, 'granja_san_miguel@email.com', 'Kilómetro 10 vía a Cali, Valle del Cauca'),
(3, 3, 2147483647, 'finca_los_pinos@email.com', 'Zona rural, Boyacá'),
(4, 4, 2147483647, 'granja_santa_rita@email.com', 'Municipio de Chía, Cundinamarca'),
(5, 5, 2147483647, 'agropecuaria_sol_naciente@email.com', 'Corregimiento El Carmen, Santander');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial`
--

CREATE TABLE `historial` (
  `Id_historial` int(11) NOT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_planta` int(11) DEFAULT NULL,
  `Descripcion_evento` text DEFAULT NULL,
  `Fecha_evento` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `historial`
--

INSERT INTO `historial` (`Id_historial`, `Id_animal`, `Id_planta`, `Descripcion_evento`, `Fecha_evento`) VALUES
(1, 101, NULL, 'Vacunación contra fiebre aftosa', '2025-03-10'),
(2, 102, NULL, 'Revisión veterinaria gallinas ponedoras', '2025-03-11'),
(3, NULL, 1, 'Poda de mantenimiento del café', '2025-03-12'),
(4, 201, NULL, 'Control sanitario en cerdos', '2025-03-13'),
(5, NULL, 2, 'Aplicación de fungicida en cultivos de plátano', '2025-03-14');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenes`
--

CREATE TABLE `imagenes` (
  `Id_imagen` int(11) NOT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_planta` int(11) DEFAULT NULL,
  `URL_imagen` varchar(255) DEFAULT NULL,
  `Fecha_subida` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `imagenes`
--

INSERT INTO `imagenes` (`Id_imagen`, `Id_animal`, `Id_planta`, `URL_imagen`, `Fecha_subida`) VALUES
(1, 101, NULL, 'https://www.google.com/imgres?q=vaca%20holstein&imgurl=http%3A%2F%2Flicnz.com%2Fwp-content%2Fuploads%2F2020%2F10%2FHolstein-Friesian-bull-Mint-Edition-Front-on.jpg&imgrefurl=https%3A%2F%2Flicnz.com%2Fes%2Fproducts-services%2Flic-cow-breeds%2F&docid=f4QoZQ', '2025-03-10'),
(2, 102, NULL, 'https://www.google.com/imgres?q=gallina%20criolla&imgurl=https%3A%2F%2Fas2.ftcdn.net%2Fv2%2Fjpg%2F05%2F20%2F39%2F79%2F1000_F_520397931_51f1NE81nizNYxpMv3Y2tR59s8M3kjWO.jpg&imgrefurl=https%3A%2F%2Fstock.adobe.com%2Fes%2Fsearch%3Fk%3D%2522gallina%2Bcriolla%', '2025-03-11'),
(3, NULL, 1, 'https://www.google.com/imgres?q=cafe%20colombiano&imgurl=https%3A%2F%2Fcolombia.co%2Fsites%2Fdefault%2Ffiles%2Finline-images%2Fsemillas-de-cafe.jpeg&imgrefurl=https%3A%2F%2Fcolombia.co%2Fcultura-colombiana%2Fgastronomia%2Fcafe-colombiano&docid=-xOnTCkldGs', '2025-03-12'),
(4, 201, NULL, 'https://www.google.com/imgres?q=cerdo%20de%20engorde&imgurl=https%3A%2F%2Finnovad-global.com%2Fsites%2Fdefault%2Ffiles%2Fparagraph%2Fimage%2F2018-11%2Fgrower592px2.jpg&imgrefurl=https%3A%2F%2Finnovad-global.com%2Fes%2Fcerdos-de-engorde&docid=Qrvd_7HwJQAKt', '2025-03-13'),
(5, NULL, 2, 'https://www.google.com/imgres?q=platano%20colombiano&imgurl=https%3A%2F%2Fimg.lalr.co%2Fcms%2F2019%2F11%2F29144731%2Fplatano-1.jpg%3Fr%3D16_9%26w%3D388&imgrefurl=https%3A%2F%2Fwww.agronegocios.co%2Fplatano-colombiano&docid=KqRULFMX9BHYjM&tbnid=MZVRE96D4D1', '2025-03-14');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `plantas`
--

CREATE TABLE `plantas` (
  `Id_planta` int(11) NOT NULL,
  `Nombre_cientifico` varchar(100) NOT NULL,
  `Nombre_comun` varchar(100) DEFAULT NULL,
  `Ubicacion_planta` varchar(255) DEFAULT NULL,
  `Estado_planta` enum('Sano','Enfermo','Recuperación') DEFAULT 'Sano',
  `Descripcion` text DEFAULT NULL,
  `Fecha_registro_planta` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `plantas`
--

INSERT INTO `plantas` (`Id_planta`, `Nombre_cientifico`, `Nombre_comun`, `Ubicacion_planta`, `Estado_planta`, `Descripcion`, `Fecha_registro_planta`) VALUES
(1, 'Coffea arabica', 'Café', 'Lote 3 - Finca El Paraíso', 'Sano', 'Cultivo de café arábigo en óptimas condiciones.', '2025-03-13 01:25:06'),
(2, 'Musa paradisiaca', 'Plátano', 'Zona de cultivo A', 'Enfermo', 'Plantas afectadas por sigatoka negra.', '2025-03-13 01:25:06'),
(3, 'Persea americana', 'Aguacate Hass', 'Huerto principal', 'Sano', 'Árboles en producción de aguacate Hass.', '2025-03-13 01:25:06'),
(4, 'Zea mays', 'Maíz', 'Parcela 2', 'Recuperación', 'Cultivo afectado por plagas, en proceso de recuperación.', '2025-03-13 01:25:06'),
(5, 'Theobroma cacao', 'Cacao', 'Sector sur de la finca', 'Sano', 'Plantas de cacao en etapa de floración.', '2025-03-13 01:25:06');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reportes`
--

CREATE TABLE `reportes` (
  `Id_reporte` int(11) NOT NULL,
  `Id_usuario` int(11) DEFAULT NULL,
  `Id_planta` int(11) DEFAULT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Tipo` enum('Planta','Animal') NOT NULL,
  `Fecha_reporte` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `reportes`
--

INSERT INTO `reportes` (`Id_reporte`, `Id_usuario`, `Id_planta`, `Id_animal`, `Tipo`, `Fecha_reporte`) VALUES
(1, 1, NULL, 101, 'Animal', '2025-03-13 01:29:02'),
(2, 2, NULL, 102, 'Animal', '2025-03-13 01:29:02'),
(3, 3, 1, NULL, 'Planta', '2025-03-13 01:29:02'),
(4, 4, 2, NULL, 'Planta', '2025-03-13 01:29:02'),
(5, 5, NULL, 201, 'Animal', '2025-03-13 01:29:02');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tratamientos`
--

CREATE TABLE `tratamientos` (
  `Id_tratamiento` int(11) NOT NULL,
  `Id_reporte` int(11) DEFAULT NULL,
  `Descripcion` text NOT NULL,
  `Fecha_inicio` date NOT NULL,
  `Fecha_fin` date DEFAULT NULL,
  `Resultado` enum('Exitoso','En Proceso','Fallido') DEFAULT 'En Proceso'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `tratamientos`
--

INSERT INTO `tratamientos` (`Id_tratamiento`, `Id_reporte`, `Descripcion`, `Fecha_inicio`, `Fecha_fin`, `Resultado`) VALUES
(1, 1, 'Aplicación de antibióticos para fiebre aftosa', '2025-03-10', '2025-03-15', 'Exitoso'),
(2, 2, 'Suplementación de calcio para gallinas', '2025-03-11', '2025-03-20', 'En Proceso'),
(3, 3, 'Poda y control de plagas en café', '2025-03-12', '2025-03-19', 'En Proceso'),
(4, 4, 'Aplicación de fungicida en plátanos', '2025-03-13', '2025-03-18', 'Exitoso'),
(5, 5, 'Tratamiento para neumonía en cerdos', '2025-03-14', '2025-03-19', 'En Proceso');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubicacion`
--

CREATE TABLE `ubicacion` (
  `Id_ubicacion` int(11) NOT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_planta` int(11) DEFAULT NULL,
  `Latitud` decimal(10,8) DEFAULT NULL,
  `Longitud` decimal(11,8) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `ubicacion`
--

INSERT INTO `ubicacion` (`Id_ubicacion`, `Id_animal`, `Id_planta`, `Latitud`, `Longitud`, `Descripcion`) VALUES
(1, 101, NULL, 6.24420300, -75.58121200, 'Corral de bovinos - Finca El Paraíso'),
(2, 102, NULL, 4.60971000, -74.08175000, 'Gallinero central - Granja San Miguel'),
(3, NULL, 1, 5.53527800, -73.36777800, 'Cultivo de café - Boyacá'),
(4, NULL, 2, 7.11392000, -73.11980000, 'Cultivo de plátanos - Santander'),
(5, 201, NULL, 3.43722000, -76.52250000, 'Corral de cerdos - Valle del Cauca');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `Id_usuario` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Correo` varchar(100) NOT NULL,
  `Telefono` varchar(20) DEFAULT NULL,
  `Tipo_usuario` enum('Investigador','Veterinario','Botanico','Administrador') NOT NULL,
  `Contraseña` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`Id_usuario`, `Nombre`, `Correo`, `Telefono`, `Tipo_usuario`, `Contraseña`) VALUES
(1, 'Andrés Gómez', 'andres.gomez@email.com', '+57 3104567890', 'Veterinario', '12345'),
(2, 'Laura Sánchez', 'laura.sanchez@email.com', '+57 3205678901', 'Botanico', '12345'),
(3, 'Carlos Ramírez', 'Carl123@gmail.com', '+57 3156789012', 'Investigador', '12345'),
(4, 'Diana Castro', 'diana.castro@email.com', '+57 3227890123', 'Administrador', '12345'),
(5, 'Fernando López', 'fernando.lopez@email.com', '+57 3008901234', 'Veterinario', '12345');

--
-- Disparadores `usuario`
--
DELIMITER $$
CREATE TRIGGER `after_usuario_insert` AFTER INSERT ON `usuario` FOR EACH ROW BEGIN
    INSERT INTO historial_usuarios (Id_usuario, Accion, Datos_anteriores, Mensaje)
    VALUES (NEW.Id_usuario, 'INSERT', NULL, CONCAT('Nuevo usuario agregado: ', NEW.Id_usuario));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vacunaciones`
--

CREATE TABLE `vacunaciones` (
  `Id_vacunacion` int(11) NOT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_estado` int(11) DEFAULT NULL,
  `vacuna` varchar(100) DEFAULT NULL,
  `Fecha_Vacunacion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `vacunaciones`
--

INSERT INTO `vacunaciones` (`Id_vacunacion`, `Id_animal`, `Id_estado`, `vacuna`, `Fecha_Vacunacion`) VALUES
(1, 101, 1, 'Fiebre aftosa', '2025-03-10'),
(2, 102, 2, 'Newcastle', '2025-03-11'),
(3, 201, 3, 'Neumonía porcina', '2025-03-12'),
(4, 202, 4, 'Brucelosis caprina', '2025-03-13'),
(5, 301, 5, 'Viruela aviar', '2025-03-14');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas_animales`
--

CREATE TABLE `ventas_animales` (
  `Id_ventas` int(11) NOT NULL,
  `Id_animal` int(11) DEFAULT NULL,
  `Id_usuario` int(11) DEFAULT NULL,
  `Id_cliente` int(11) DEFAULT NULL,
  `Id_estado` int(11) DEFAULT NULL,
  `Precio` decimal(10,2) DEFAULT NULL,
  `Fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `ventas_animales`
--

INSERT INTO `ventas_animales` (`Id_ventas`, `Id_animal`, `Id_usuario`, `Id_cliente`, `Id_estado`, `Precio`, `Fecha`) VALUES
(1, 101, 1, 1, 1, 2500000.00, '2025-03-10'),
(2, 102, 2, 2, 2, 50000.00, '2025-03-11'),
(3, 201, 3, 3, 3, 1500000.00, '2025-03-12'),
(4, 202, 4, 4, 4, 800000.00, '2025-03-13'),
(5, 301, 5, 5, 5, 200000.00, '2025-03-14');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_alimentos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_alimentos` (
`Id_alimento` int(11)
,`Nombre_comun` varchar(100)
,`Tipo_alimento` varchar(100)
,`Cantidad_alimento` int(11)
,`Fecha_alimentacion` date
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_estado_animales`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_estado_animales` (
`Id_animal` int(11)
,`Nombre_comun` varchar(100)
,`Estado` enum('Sano','Enfermo','Recuperación')
,`Fecha_registro` date
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_eventos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_eventos` (
`Id_evento` int(11)
,`Tipo_evento` varchar(100)
,`Fecha_registro` date
,`Descripcion_evento` text
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_plantas_tratamientos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_plantas_tratamientos` (
`Id_planta` int(11)
,`Nombre_comun` varchar(100)
,`Ubicacion_planta` varchar(255)
,`Descripcion` text
,`Resultado` enum('Exitoso','En Proceso','Fallido')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_reportes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_reportes` (
`Id_reporte` int(11)
,`Reportado_por` varchar(100)
,`Tipo` enum('Planta','Animal')
,`Fecha_reporte` timestamp
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_ubicaciones`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_ubicaciones` (
`Id_ubicacion` int(11)
,`Nombre` varchar(100)
,`Latitud` decimal(10,8)
,`Longitud` decimal(11,8)
,`Descripcion` varchar(255)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_vacunaciones`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_vacunaciones` (
`Id_vacunacion` int(11)
,`Nombre_comun` varchar(100)
,`vacuna` varchar(100)
,`Fecha_Vacunacion` date
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_ventas_animales`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_ventas_animales` (
`Id_ventas` int(11)
,`Nombre_comun` varchar(100)
,`Vendedor` varchar(100)
,`Comprador` varchar(100)
,`Precio` decimal(10,2)
,`Fecha` date
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_ventas_detalladas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_ventas_detalladas` (
`Id_ventas` int(11)
,`Nombre_Animal` varchar(100)
,`Especie` varchar(100)
,`Nombre_Cliente` varchar(100)
,`Precio` decimal(10,2)
,`Fecha` date
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_alimentos`
--
DROP TABLE IF EXISTS `vista_alimentos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_alimentos`  AS SELECT `alimentos`.`Id_alimento` AS `Id_alimento`, `animales`.`Nombre_comun` AS `Nombre_comun`, `alimentos`.`Tipo_alimento` AS `Tipo_alimento`, `alimentos`.`Cantidad_alimento` AS `Cantidad_alimento`, `alimentos`.`Fecha_alimentacion` AS `Fecha_alimentacion` FROM (`alimentos` join `animales` on(`alimentos`.`Id_animal` = `animales`.`Id_animal`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_estado_animales`
--
DROP TABLE IF EXISTS `vista_estado_animales`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_estado_animales`  AS SELECT `animales`.`Id_animal` AS `Id_animal`, `animales`.`Nombre_comun` AS `Nombre_comun`, `estado_animal`.`Estado` AS `Estado`, `estado_animal`.`Fecha_registro` AS `Fecha_registro` FROM (`animales` join `estado_animal` on(`animales`.`Id_animal` = `estado_animal`.`Id_animal`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_eventos`
--
DROP TABLE IF EXISTS `vista_eventos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_eventos`  AS SELECT `evento`.`Id_evento` AS `Id_evento`, `evento`.`Tipo_evento` AS `Tipo_evento`, `evento`.`Fecha_registro` AS `Fecha_registro`, `historial`.`Descripcion_evento` AS `Descripcion_evento` FROM (`evento` join `historial` on(`evento`.`Id_historial` = `historial`.`Id_historial`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_plantas_tratamientos`
--
DROP TABLE IF EXISTS `vista_plantas_tratamientos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_plantas_tratamientos`  AS SELECT `plantas`.`Id_planta` AS `Id_planta`, `plantas`.`Nombre_comun` AS `Nombre_comun`, `plantas`.`Ubicacion_planta` AS `Ubicacion_planta`, `tratamientos`.`Descripcion` AS `Descripcion`, `tratamientos`.`Resultado` AS `Resultado` FROM ((`plantas` join `reportes` on(`plantas`.`Id_planta` = `reportes`.`Id_planta`)) join `tratamientos` on(`reportes`.`Id_reporte` = `tratamientos`.`Id_reporte`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_reportes`
--
DROP TABLE IF EXISTS `vista_reportes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_reportes`  AS SELECT `reportes`.`Id_reporte` AS `Id_reporte`, `usuario`.`Nombre` AS `Reportado_por`, `reportes`.`Tipo` AS `Tipo`, `reportes`.`Fecha_reporte` AS `Fecha_reporte` FROM (`reportes` join `usuario` on(`reportes`.`Id_reporte` = `usuario`.`Id_usuario`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_ubicaciones`
--
DROP TABLE IF EXISTS `vista_ubicaciones`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_ubicaciones`  AS SELECT `ubicacion`.`Id_ubicacion` AS `Id_ubicacion`, coalesce(`animales`.`Nombre_comun`,`plantas`.`Nombre_comun`) AS `Nombre`, `ubicacion`.`Latitud` AS `Latitud`, `ubicacion`.`Longitud` AS `Longitud`, `ubicacion`.`Descripcion` AS `Descripcion` FROM ((`ubicacion` left join `animales` on(`ubicacion`.`Id_animal` = `animales`.`Id_animal`)) left join `plantas` on(`ubicacion`.`Id_planta` = `plantas`.`Id_planta`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_vacunaciones`
--
DROP TABLE IF EXISTS `vista_vacunaciones`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_vacunaciones`  AS SELECT `vacunaciones`.`Id_vacunacion` AS `Id_vacunacion`, `animales`.`Nombre_comun` AS `Nombre_comun`, `vacunaciones`.`vacuna` AS `vacuna`, `vacunaciones`.`Fecha_Vacunacion` AS `Fecha_Vacunacion` FROM (`vacunaciones` join `animales` on(`vacunaciones`.`Id_animal` = `animales`.`Id_animal`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_ventas_animales`
--
DROP TABLE IF EXISTS `vista_ventas_animales`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_ventas_animales`  AS SELECT `ventas_animales`.`Id_ventas` AS `Id_ventas`, `animales`.`Nombre_comun` AS `Nombre_comun`, `usuario`.`Nombre` AS `Vendedor`, `clientes`.`Nombre_cliente` AS `Comprador`, `ventas_animales`.`Precio` AS `Precio`, `ventas_animales`.`Fecha` AS `Fecha` FROM (((`ventas_animales` join `animales` on(`ventas_animales`.`Id_animal` = `animales`.`Id_animal`)) join `usuario` on(`ventas_animales`.`Id_usuario` = `usuario`.`Id_usuario`)) join `clientes` on(`ventas_animales`.`Id_cliente` = `clientes`.`Id_cliente`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_ventas_detalladas`
--
DROP TABLE IF EXISTS `vista_ventas_detalladas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_ventas_detalladas`  AS SELECT `ventas_animales`.`Id_ventas` AS `Id_ventas`, `animales`.`Nombre_comun` AS `Nombre_Animal`, `animales`.`Especie` AS `Especie`, `clientes`.`Nombre_cliente` AS `Nombre_Cliente`, `ventas_animales`.`Precio` AS `Precio`, `ventas_animales`.`Fecha` AS `Fecha` FROM ((`ventas_animales` join `animales` on(`ventas_animales`.`Id_animal` = `animales`.`Id_animal`)) join `clientes` on(`ventas_animales`.`Id_cliente` = `clientes`.`Id_cliente`)) ORDER BY `ventas_animales`.`Fecha` DESC ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alimentos`
--
ALTER TABLE `alimentos`
  ADD PRIMARY KEY (`Id_alimento`),
  ADD KEY `Id_animal` (`Id_animal`),
  ADD KEY `Id_granja` (`Id_granja`),
  ADD KEY `Id_ventas` (`Id_ventas`);

--
-- Indices de la tabla `animales`
--
ALTER TABLE `animales`
  ADD PRIMARY KEY (`Id_animal`),
  ADD KEY `Usuario_animal` (`Usuario_animal`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`Id_cliente`),
  ADD KEY `Id_animal` (`Id_animal`);

--
-- Indices de la tabla `diagnostico`
--
ALTER TABLE `diagnostico`
  ADD PRIMARY KEY (`Id_diagnostico`),
  ADD KEY `Id_reporte` (`Id_reporte`);

--
-- Indices de la tabla `estado_animal`
--
ALTER TABLE `estado_animal`
  ADD PRIMARY KEY (`Id_estado`);

--
-- Indices de la tabla `evento`
--
ALTER TABLE `evento`
  ADD PRIMARY KEY (`Id_evento`),
  ADD KEY `Id_historial` (`Id_historial`);

--
-- Indices de la tabla `granja`
--
ALTER TABLE `granja`
  ADD PRIMARY KEY (`Id_granja`),
  ADD KEY `Id_usuario` (`Id_usuario`);

--
-- Indices de la tabla `historial`
--
ALTER TABLE `historial`
  ADD PRIMARY KEY (`Id_historial`),
  ADD KEY `Id_animal` (`Id_animal`),
  ADD KEY `Id_planta` (`Id_planta`);

--
-- Indices de la tabla `imagenes`
--
ALTER TABLE `imagenes`
  ADD PRIMARY KEY (`Id_imagen`),
  ADD KEY `Id_animal` (`Id_animal`),
  ADD KEY `Id_planta` (`Id_planta`);

--
-- Indices de la tabla `plantas`
--
ALTER TABLE `plantas`
  ADD PRIMARY KEY (`Id_planta`);

--
-- Indices de la tabla `reportes`
--
ALTER TABLE `reportes`
  ADD PRIMARY KEY (`Id_reporte`),
  ADD KEY `Id_usuario` (`Id_usuario`),
  ADD KEY `Id_planta` (`Id_planta`),
  ADD KEY `Id_animal` (`Id_animal`);

--
-- Indices de la tabla `tratamientos`
--
ALTER TABLE `tratamientos`
  ADD PRIMARY KEY (`Id_tratamiento`),
  ADD KEY `Id_reporte` (`Id_reporte`);

--
-- Indices de la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  ADD PRIMARY KEY (`Id_ubicacion`),
  ADD KEY `Id_animal` (`Id_animal`),
  ADD KEY `Id_planta` (`Id_planta`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`Id_usuario`),
  ADD UNIQUE KEY `Correo` (`Correo`);

--
-- Indices de la tabla `vacunaciones`
--
ALTER TABLE `vacunaciones`
  ADD PRIMARY KEY (`Id_vacunacion`),
  ADD KEY `Id_animal` (`Id_animal`),
  ADD KEY `Id_estado` (`Id_estado`);

--
-- Indices de la tabla `ventas_animales`
--
ALTER TABLE `ventas_animales`
  ADD PRIMARY KEY (`Id_ventas`),
  ADD KEY `Id_animal` (`Id_animal`),
  ADD KEY `Id_usuario` (`Id_usuario`),
  ADD KEY `Id_cliente` (`Id_cliente`),
  ADD KEY `Id_estado` (`Id_estado`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alimentos`
--
ALTER TABLE `alimentos`
  MODIFY `Id_alimento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `animales`
--
ALTER TABLE `animales`
  MODIFY `Id_animal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=302;

--
-- AUTO_INCREMENT de la tabla `diagnostico`
--
ALTER TABLE `diagnostico`
  MODIFY `Id_diagnostico` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `plantas`
--
ALTER TABLE `plantas`
  MODIFY `Id_planta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `reportes`
--
ALTER TABLE `reportes`
  MODIFY `Id_reporte` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `Id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `ventas_animales`
--
ALTER TABLE `ventas_animales`
  MODIFY `Id_ventas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `alimentos`
--
ALTER TABLE `alimentos`
  ADD CONSTRAINT `alimentos_ibfk_1` FOREIGN KEY (`Id_animal`) REFERENCES `animales` (`Id_animal`),
  ADD CONSTRAINT `alimentos_ibfk_2` FOREIGN KEY (`Id_granja`) REFERENCES `granja` (`Id_granja`),
  ADD CONSTRAINT `alimentos_ibfk_3` FOREIGN KEY (`Id_ventas`) REFERENCES `ventas_animales` (`Id_ventas`);

--
-- Filtros para la tabla `animales`
--
ALTER TABLE `animales`
  ADD CONSTRAINT `animales_ibfk_1` FOREIGN KEY (`Usuario_animal`) REFERENCES `usuario` (`Id_usuario`);

--
-- Filtros para la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `clientes_ibfk_1` FOREIGN KEY (`Id_animal`) REFERENCES `animales` (`Id_animal`);

--
-- Filtros para la tabla `diagnostico`
--
ALTER TABLE `diagnostico`
  ADD CONSTRAINT `diagnostico_ibfk_1` FOREIGN KEY (`Id_reporte`) REFERENCES `reportes` (`Id_reporte`);

--
-- Filtros para la tabla `evento`
--
ALTER TABLE `evento`
  ADD CONSTRAINT `evento_ibfk_1` FOREIGN KEY (`Id_historial`) REFERENCES `historial` (`Id_historial`);

--
-- Filtros para la tabla `granja`
--
ALTER TABLE `granja`
  ADD CONSTRAINT `granja_ibfk_1` FOREIGN KEY (`Id_usuario`) REFERENCES `usuario` (`Id_usuario`);

--
-- Filtros para la tabla `historial`
--
ALTER TABLE `historial`
  ADD CONSTRAINT `historial_ibfk_1` FOREIGN KEY (`Id_animal`) REFERENCES `animales` (`Id_animal`),
  ADD CONSTRAINT `historial_ibfk_2` FOREIGN KEY (`Id_planta`) REFERENCES `plantas` (`Id_planta`);

--
-- Filtros para la tabla `imagenes`
--
ALTER TABLE `imagenes`
  ADD CONSTRAINT `imagenes_ibfk_1` FOREIGN KEY (`Id_animal`) REFERENCES `animales` (`Id_animal`),
  ADD CONSTRAINT `imagenes_ibfk_2` FOREIGN KEY (`Id_planta`) REFERENCES `plantas` (`Id_planta`);

--
-- Filtros para la tabla `reportes`
--
ALTER TABLE `reportes`
  ADD CONSTRAINT `reportes_ibfk_1` FOREIGN KEY (`Id_usuario`) REFERENCES `usuario` (`Id_usuario`),
  ADD CONSTRAINT `reportes_ibfk_2` FOREIGN KEY (`Id_planta`) REFERENCES `plantas` (`Id_planta`),
  ADD CONSTRAINT `reportes_ibfk_3` FOREIGN KEY (`Id_animal`) REFERENCES `animales` (`Id_animal`);

--
-- Filtros para la tabla `tratamientos`
--
ALTER TABLE `tratamientos`
  ADD CONSTRAINT `tratamientos_ibfk_1` FOREIGN KEY (`Id_reporte`) REFERENCES `reportes` (`Id_reporte`);

--
-- Filtros para la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  ADD CONSTRAINT `ubicacion_ibfk_1` FOREIGN KEY (`Id_animal`) REFERENCES `animales` (`Id_animal`),
  ADD CONSTRAINT `ubicacion_ibfk_2` FOREIGN KEY (`Id_planta`) REFERENCES `plantas` (`Id_planta`);

--
-- Filtros para la tabla `vacunaciones`
--
ALTER TABLE `vacunaciones`
  ADD CONSTRAINT `vacunaciones_ibfk_1` FOREIGN KEY (`Id_animal`) REFERENCES `animales` (`Id_animal`),
  ADD CONSTRAINT `vacunaciones_ibfk_2` FOREIGN KEY (`Id_estado`) REFERENCES `estado_animal` (`Id_estado`);

--
-- Filtros para la tabla `ventas_animales`
--
ALTER TABLE `ventas_animales`
  ADD CONSTRAINT `ventas_animales_ibfk_1` FOREIGN KEY (`Id_animal`) REFERENCES `animales` (`Id_animal`) ON DELETE SET NULL,
  ADD CONSTRAINT `ventas_animales_ibfk_2` FOREIGN KEY (`Id_usuario`) REFERENCES `usuario` (`Id_usuario`) ON DELETE SET NULL,
  ADD CONSTRAINT `ventas_animales_ibfk_3` FOREIGN KEY (`Id_cliente`) REFERENCES `clientes` (`Id_cliente`) ON DELETE SET NULL,
  ADD CONSTRAINT `ventas_animales_ibfk_4` FOREIGN KEY (`Id_estado`) REFERENCES `estado_animal` (`Id_estado`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
