<?php
$dsn = "mysql:host=localhost;dbname=login_granja;charset=utf8mb4";
$user = "root";
$password = "";

try {
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM vista_alimentos"; 
    $stmt = $pdo->query($sql);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>
                <td>{$row['Id_alimento']}</td>
                <td>{$row['Nombre_comun']}</td>
                <td>{$row['Tipo_alimento']}</td>
                <td>{$row['Cantidad_alimento']}</td>
                <td>{$row['Fecha_alimentacion']}</td>
                </tr>";
    }

} catch (PDOException $e) {
    echo "<tr><td colspan='5'>Error: " . $e->getMessage() . "</td></tr>";
}
?>

