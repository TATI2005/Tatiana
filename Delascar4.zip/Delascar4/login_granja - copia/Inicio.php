<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/inicio.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Inicio</title>
</head>
<body>
<nav>
        <div class="logo"> <img src="IMG/Vanilla-PMP_Collection-Carousel-0_Buzzy-Bees_1280x768.jpg"></div>
        <ul class="menu">
            <li><a href="Inicio.php">Inicio</a></li>
            <li><a href="../granja/Pagina.php">CRUD</a></li>
            <li><a href="vista.php">Vistas del login_granja</a></li>
            <li><a href="Saludos.php">Cerrar Sesion</a></li>
        </ul>
</nav><br>
    <h2>REGISTRO DE ANIMALES, GRANJER@!</h2>
    <form action="registro_animal.php" method="POST"> 
        <label for="tipo_animal">Tipo de Animal:</label>
        <select name="Tipo_animal" id="tipo_animal" required>
            <option value="Pollo">Pollo</option>
            <option value="Vaca">Vaca</option>
            <option value="Toro">Toro</option>
            <option value="Pez">Pez</option>
            <option value="Cerdo">Cerdo</option>
        </select>

        <label for="talla">Talla (m):</label>
        <input type="number" step="0.01" name="Talla" id="talla" required>

        <label for="peso">Peso (kg):</label>
        <input type="number" name="Peso" id="peso" required>

        <label for="edad">Edad (años):</label>
        <input type="number" name="Edad" id="edad" required>

        <label for="cantidad">Cantidad:</label>
        <input type="number" name="Cantidad" id="cantidad" required>

        <label for="dueño_animal">Identificacion del dueño del animal</label>
        <input type="text" name="Dueño_animal" id="dueño_animal" required>


        <button type="submit">Registrar</button><br>
    </form><br><br>

    <img class="minecraft" src="IMG/1366_2000.jpg">
    <i><p><h3>¡BIENVENIDO GRANJER@!<br>
        AGREGUE SU ESTADO</h3>
    </p></i>


</body>
</html>