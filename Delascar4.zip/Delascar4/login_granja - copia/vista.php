<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Alimentos</title>
    <link rel="stylesheet" href="CSS/vistas.css"> 
</head>
<body>
<nav>
        <div class="logo"> <img src="IMG/Vanilla-PMP_Collection-Carousel-0_Buzzy-Bees_1280x768.jpg"></div>
        <ul class="menu">
            <li><a href="Inicio.php">Inicio</a></li>
            <li><a href="../granja/Pagina.php">CRUD</a></li>
            <li><a href="vista.php">Vistas del login_granja</a></li>
            <li><a href="Saludos.php">Cerrar Sesion</a></li>
        </ul>
</nav><br>
<h1>vistas</h1>
<section>
    <table class="tabla1" border="1">
        <thead>
            <tr>
                <th>Id Alimento</th>
                <th>Nombre Común</th>
                <th>Tipo de Alimento</th>
                <th>Cantidad</th>
                <th>Fecha de Alimentación</th>
            </tr>
        </thead>
        <tbody>
            <?php include 'mostrarvista.php'; ?> 
        </tbody>
    </table>
</section><br>
<section>
<table  class="tabla2" border="1">
        <thead>
            <tr>
                <th>Id Animal</th>
                <th>Nombre Común</th>
                <th>Estado</th>
                <th>Fecha de Registro</th>
            </tr>
        </thead>
        <tbody>
            <?php include 'mostrarvista2.php'; ?> 
        </tbody>
    </table>
</section><br>
<section>
<table  class="tabla3" border="1">
        <thead>
            <tr>
                <th>Id_evento</th>
                <th>Tipo_evento</th>
                <th>Fecha_registro</th>
                <th>Descripcion_evento</th>
            </tr>
        </thead>
        <tbody>
            <?php include 'mostrarvista3.php'; ?> 
        </tbody>
    </table>
</section><br>
<section>
<table class="tabla4" border="1">
        <thead>
            <tr>
                <th>Id_Planta</th>
                <th>Nombre_comun</th>
                <th>Ubicacion_planta</th>
                <th>Descripcion</th>
                <th>Resultado</th>
            </tr>
        </thead>
        <tbody>
            <?php include 'mostrarvista4.php'; ?> 
        </tbody>
    </table>
</section><br>
<section>
<table  class="tabla5" border="1">
        <thead>
            <tr>
                <th>Id_entas</th>
                <th>Nombre_Animal</th>
                <th>Especie</th>
                <th>Nombre_Cliente</th>
                <th>Precio</th>
                <th>Fecha</th>
            </tr>
        </thead>
        <tbody>
            <?php include 'mostrarvista5.php'; ?> 
        </tbody>
    </table>
</section><br>
<section>
<table  class="tabla6" border="1">
        <thead>
            <tr>
                <th>Id_reporte</th>
                <th>Reportado_por</th>
                <th>Tipo</th>
                <th>Fecha_reporte</th>
            </tr>
        </thead>
        <tbody>
            <?php include 'mostrarvista6.php'; ?> 
        </tbody>
    </table>
</section><br>
<section>
<table  class="tabla7" border="1">
        <thead>
            <tr>
                <th>Id_ubicacion</th>
                <th>Nombre</th>
                <th>Latitud</th>
                <th>longitud</th>
                <th>Descripcion</th>
            </tr>
        </thead>
        <tbody>
            <?php include 'mostrarvista7.php'; ?> 
        </tbody>
    </table>
</section><br>
<section>
<table  class="tabla8" border="1">
        <thead>
            <tr>
                <th>Id_vacunacion</th>
                <th>Nombre_comun</th>
                <th>vacuna</th>
                <th>Fecha_Vacunacion</th>
            </tr>
        </thead>
        <tbody>
            <?php include 'mostrarvista8.php'; ?> 
        </tbody>
    </table>
</section><br>
<section>
<table border="1">
        <thead>
            <tr>
                <th>Id_ventas</th>
                <th>Nombre_comun</th>
                <th>Vendedor</th>
                <th>Comprador</th>
                <th>Precio</th>
                <th>Fecha</th>
            </tr>
        </thead>
        <tbody>
            <?php include 'mostrarvista9.php'; ?> 
        </tbody>
    </table>
</section><br>
</body>
</html>
