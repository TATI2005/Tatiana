<?php
$dsn = "mysql:host=localhost;dbname=login_granja;charset=utf8mb4";
$user = "root";
$password = "";

try {
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM vista_reportes"; 
    $stmt = $pdo->query($sql);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>
                <td>{$row['Id_reporte']}</td>
                <td>{$row['Reportado_por']}</td>
                <td>{$row['Tipo']}</td>
                <td>{$row['Fecha_reporte']}</td>
            </tr>";
    }

} catch (PDOException $e) {
    echo "<tr><td colspan='4'>Error: " . $e->getMessage() . "</td></tr>";
}
?>