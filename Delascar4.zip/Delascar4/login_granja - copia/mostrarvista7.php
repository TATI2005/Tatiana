<?php
$dsn = "mysql:host=localhost;dbname=login_granja;charset=utf8mb4";
$user = "root";
$password = "";

try {
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM vista_ubicaciones"; 
    $stmt = $pdo->query($sql);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>
                <td>{$row['Id_ubicacion']}</td>
                <td>{$row['Nombre']}</td>
                <td>{$row['Latitud']}</td>
                <td>{$row['Longitud']}</td>
                <td>{$row['Descripcion']}</td>
            </tr>";
    }

} catch (PDOException $e) {
    echo "<tr><td colspan='5'>Error: " . $e->getMessage() . "</td></tr>";
}
?>