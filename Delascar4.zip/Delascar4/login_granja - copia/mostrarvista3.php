<?php
$dsn = "mysql:host=localhost;dbname=login_granja;charset=utf8mb4";
$user = "root";
$password = "";

try {
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM vista_eventos"; 
    $stmt = $pdo->query($sql);


    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>
                <td>{$row['Id_evento']}</td>
                <td>{$row['Tipo_evento']}</td>
                <td>{$row['Fecha_registro']}</td>
                <td>{$row['Descripcion_evento']}</td>
                </tr>";
    }

} catch (PDOException $e) {
    echo "<tr><td colspan='4'>Error: " . $e->getMessage() . "</td></tr>";
}
?>