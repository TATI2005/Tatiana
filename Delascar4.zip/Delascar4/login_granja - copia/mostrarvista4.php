<?php
$dsn = "mysql:host=localhost;dbname=login_granja;charset=utf8mb4";
$user = "root";
$password = "";

try {
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM vista_plantas_tratamientos"; 
    $stmt = $pdo->query($sql);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>
                <td>{$row['Id_planta']}</td>
                <td>{$row['Nombre_comun']}</td>
                <td>{$row['Ubicacion_planta']}</td>
                <td>{$row['Descripcion']}</td>
                <td>{$row['Resultado']}</td>
                </tr>";
    }

} catch (PDOException $e) {
    echo "<tr><td colspan='5'>Error: " . $e->getMessage() . "</td></tr>";
}
?>