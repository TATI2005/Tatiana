<?php 
    include('conexion.php');
    $Id_usuario = $_REQUEST['Id_usuario'];
    $sql = "DELETE FROM usuario WHERE Id_usuario='$Id_usuario'";
    $query = mysqli_query($conexion, $sql);

    if($query){
        header("Location: index.php");
    }
?>