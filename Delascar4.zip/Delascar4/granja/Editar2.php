<?php 
    include("conexion.php");

    $Id_animal = $_POST['Id_animal'];
    $Tipo_animal = $_POST['Tipo_animal'];
    $Talla = $_POST['Talla'];
    $Peso = $_POST['Peso'];
    $Edad = $_POST['Edad'];
    $Cantidad = $_POST['Cantidad'];
    $Dueño_animal = $_POST['Dueño_animal'];

    
    $sql = "UPDATE animales SET Tipo_animal='$Tipo_animal', Talla='$Talla', Peso='$Peso', 
    Edad='$Edad', Cantidad='$Cantidad', Dueño_animal='$Dueño_animal' WHERE Id_animal='$Id_animal'";
    
    $query=mysqli_query($conexion, $sql);
    
    if($query){
        header("Location: index2.php");
    }


?>