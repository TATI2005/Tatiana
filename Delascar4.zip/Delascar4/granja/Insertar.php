<?php 
    include('conexion.php');

    $Id_usuario = $_POST['Id_usuario'];
    $Usuario = $_POST['Usuario'];
    $Correo = $_POST['Correo'];
    $Telefono = $_POST['Telefono'];
    $Contraseña = $_POST['Contraseña'];

    $sql = "INSERT INTO usuario (Id_usuario, Usuario, Correo, Telefono, Contraseña) VALUES('$Id_usuario','$Usuario','$Correo','$Telefono','$Contraseña')";
    $query = mysqli_query($conexion, $sql);

    if($query === TRUE){
        header("Location: index.php");
    }


?>