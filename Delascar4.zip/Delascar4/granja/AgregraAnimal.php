<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Agregar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <h1 class="bg-dark p-3 text-light text-center">Agregar Animal</h1><br><br>
    <div class="container">
        <form action="Insertar2.php" method="POST">
            <div class="mb-3">
                <input type="text" class="form-control" placeholder="Id_animal" name="Id_animal"><br>
                <input type="text" class="form-control" placeholder="Tipo_animal" name="Tipo_animal"><br>
                <input type="text" class="form-control" placeholder="Talla" name="Talla"><br>
                <input type="tel" class="form-control" placeholder="Peso" name="Peso"><br>
                <input type="text" class="form-control" placeholder="Edad" name="Edad"><br>
                <input type="text" class="form-control" placeholder="Cantidad" name="Cantidad"><br>
                <input type="text" class="form-control" placeholder="Dueño_animal" name="Dueño_animal"><br>
            </div><br>
            <div class="container">
                <button type="submit" class="btn btn-primary">Agregrar Animales</button>
                <a class="btn btn-dark" href="index2.php">regresar</a>
            </div>

        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>