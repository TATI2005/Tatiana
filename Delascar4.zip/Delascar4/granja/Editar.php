<?php 
    include("conexion.php");

    $Id_usuario = $_POST['Id_usuario'];
    $Usuario = $_POST['Usuario'];
    $Correo = $_POST['Correo'];
    $Telefono = $_POST['Telefono'];
    $Contraseña = $_POST['Contraseña'];

    $sql = "UPDATE usuario SET Usuario='$Usuario', Correo='$Correo', Telefono='$Telefono', 
    Contraseña='$Contraseña' WHERE Id_usuario='$Id_usuario'";

    $query = mysqli_query($conexion, $sql);
    
    if($query){
        header("Location: index.php");
    }


?>